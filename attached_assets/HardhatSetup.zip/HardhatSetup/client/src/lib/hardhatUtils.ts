import { apiRequest } from "./queryClient";

export async function setupHardhatEnvironment() {
  try {
    const response = await apiRequest("POST", "/api/hardhat/setup", null);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Failed to setup Hardhat environment:", error);
    throw error;
  }
}

export const defaultHardhatConfig = `require("@nomicfoundation/hardhat-toolbox");
require("@nomicfoundation/hardhat-viem"); // Use viem plugin instead of ethers

/** @type {import('hardhat/config').HardhatUserConfig} */
module.exports = {
  solidity: {
    version: "0.8.19",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200
      }
    }
  },
  networks: {
    hardhat: {
      chainId: 10, // Optimism mainnet chainId
    },
    optimism: {
      url: "https://mainnet.optimism.io",
      accounts: [\${process.env.PRIVATE_KEY}]
    },
    optimismSepolia: {
      url: "https://sepolia.optimism.io",
      accounts: [\${process.env.PRIVATE_KEY}]
    }
  },
  paths: {
    sources: "./contracts",
    tests: "./test",
    artifacts: "./artifacts"
  },
  mocha: {
    timeout: 40000
  }
};`;

export const defaultReentrancyTest = `const { expect } = require("chai");
const { viem } = require("hardhat");
const { parseEther } = require("viem");

describe("Reentrancy Attack Test", function() {
  let attackerContract;
  let vulnerableContract;
  let owner;
  let attacker;
  let publicClient;
  let walletClient;

  beforeEach(async function() {
    // Get Viem clients
    publicClient = await viem.getPublicClient();
    [walletClient] = await viem.getWalletClients();
    [owner, attacker] = await viem.getTestAccounts();
    
    // Deploy contracts using viem
    const L1CrossDomainMessengerArtifact = await import('../artifacts/contracts/L1CrossDomainMessenger.sol/L1CrossDomainMessenger.json');
    const deployedVulnerable = await viem.deployContract({
      abi: L1CrossDomainMessengerArtifact.abi,
      bytecode: L1CrossDomainMessengerArtifact.bytecode,
      account: owner.address
    });
    vulnerableContract = deployedVulnerable.contractAddress;
    
    const ReentrancyAttackerArtifact = await import('../artifacts/contracts/ReentrancyAttacker.sol/ReentrancyAttacker.json');
    const deployedAttacker = await viem.deployContract({
      abi: ReentrancyAttackerArtifact.abi,
      bytecode: ReentrancyAttackerArtifact.bytecode,
      account: owner.address,
      args: [vulnerableContract]
    });
    attackerContract = deployedAttacker.contractAddress;
  });

  it("should not allow reentrancy attacks", async function() {
    // Fund the vulnerable contract
    await walletClient.sendTransaction({
      account: owner.address,
      to: vulnerableContract,
      value: parseEther("1.0")
    });
    
    // Check balance before attack
    const initialBalance = await publicClient.getBalance({
      address: attackerContract
    });
    
    // Attempt the attack - should be rejected due to protection
    let wasRejected = false;
    try {
      await walletClient.writeContract({
        address: attackerContract,
        abi: ReentrancyAttackerArtifact.abi,
        functionName: 'attack',
        account: attacker.address,
        value: parseEther("0.1")
      });
    } catch (error) {
      wasRejected = true;
    }
    
    expect(wasRejected).to.be.true;
    
    // Check balance after attack
    const finalBalance = await publicClient.getBalance({
      address: attackerContract
    });
    
    // Ensure no ether was stolen
    expect(finalBalance).to.equal(initialBalance);
  });
});`;

export const defaultAccessControlTest = `const { expect } = require("chai");
const { viem } = require("hardhat");

describe("Access Control Test", function() {
  let contract;
  let owner;
  let user;
  let publicClient;
  let walletClient;
  let contractAbi;

  beforeEach(async function() {
    // Get Viem clients
    publicClient = await viem.getPublicClient();
    [walletClient] = await viem.getWalletClients();
    [owner, user] = await viem.getTestAccounts();
    
    // Deploy contract using viem
    const OptimismPortalArtifact = await import('../artifacts/contracts/OptimismPortal.sol/OptimismPortal.json');
    const deployedContract = await viem.deployContract({
      abi: OptimismPortalArtifact.abi,
      bytecode: OptimismPortalArtifact.bytecode,
      account: owner.address
    });
    
    contract = deployedContract.contractAddress;
    contractAbi = OptimismPortalArtifact.abi;
  });

  it("should restrict administrative functions to owner", async function() {
    // Attempt to call an admin function as non-owner
    let wasRejected = false;
    try {
      await walletClient.writeContract({
        address: contract,
        abi: contractAbi,
        functionName: 'pause',
        account: user.address
      });
    } catch (error) {
      wasRejected = true;
    }
    
    expect(wasRejected).to.be.true;
    
    // Owner should be able to call the function
    await walletClient.writeContract({
      address: contract,
      abi: contractAbi,
      functionName: 'pause',
      account: owner.address
    });
    
    // Verify the contract state reflects the change
    const isPaused = await publicClient.readContract({
      address: contract,
      abi: contractAbi,
      functionName: 'isPaused'
    });
    
    expect(isPaused).to.equal(true);
  });
});`;

export const sampleContracts = [
  {
    name: "OptimismPortal",
    address: "0x5a5e5d3a365b2e1b8e57f85db4a7eb5cae4e42a",
    source: `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract OptimismPortal {
    bool private paused;
    address private owner;

    constructor() {
        owner = msg.sender;
        paused = false;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "Not authorized");
        _;
    }

    function isPaused() external view returns (bool) {
        return paused;
    }

    function pause() external onlyOwner {
        paused = true;
    }

    function unpause() external onlyOwner {
        paused = false;
    }

    function depositTransaction() external payable {
        require(!paused, "Portal is paused");
        // Implementation would go here
    }
}`,
    network: "optimism",
    verified: true
  },
  {
    name: "L1CrossDomainMessenger",
    address: "0x2db77c9b93cf84b31198f68b40fc578577a7a12",
    source: `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract L1CrossDomainMessenger {
    mapping(bytes32 => bool) public sentMessages;
    mapping(bytes32 => bool) public receivedMessages;
    address private owner;

    constructor() {
        owner = msg.sender;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "Not authorized");
        _;
    }

    function sendMessage(
        address _target,
        bytes calldata _message,
        uint32 _gasLimit
    ) external payable {
        bytes32 messageHash = keccak256(abi.encode(_target, _message, _gasLimit));
        sentMessages[messageHash] = true;
        // Implementation would go here
    }

    function receiveMessage(
        address _sender,
        address _target,
        bytes calldata _message,
        uint32 _gasLimit
    ) external {
        bytes32 messageHash = keccak256(abi.encode(_sender, _target, _message, _gasLimit));
        require(!receivedMessages[messageHash], "Message already received");
        receivedMessages[messageHash] = true;
        // Implementation would go here
    }
}`,
    network: "optimism",
    verified: true
  }
];
