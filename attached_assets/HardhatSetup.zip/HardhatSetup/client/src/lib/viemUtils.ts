import { createPublicClient, createWalletClient, http, parseEther, Account, PrivateKeyAccount } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { optimism, optimismSepolia } from 'viem/chains';

// Chain configuration for Optimism networks
const chains = {
  optimism,
  optimismSepolia,
  localhost: {
    id: 1337,
    name: 'Localhost',
    network: 'localhost',
    nativeCurrency: {
      decimals: 18,
      name: 'Ether',
      symbol: 'ETH',
    },
    rpcUrls: {
      default: {
        http: ['http://localhost:8545'],
      },
      public: {
        http: ['http://localhost:8545'],
      },
    }
  }
};

// Create clients for different networks
const createClients = (network: 'optimism' | 'optimismSepolia' | 'localhost', privateKey?: string) => {
  const chain = chains[network];
  
  // Create public client for reading from the blockchain
  const publicClient = createPublicClient({
    chain,
    transport: http(),
  });
  
  // Create wallet client for writing to the blockchain (if private key is provided)
  let walletClient = undefined;
  let account: PrivateKeyAccount | undefined = undefined;
  
  if (privateKey) {
    // Convert private key to account
    if (privateKey.startsWith('0x')) {
      account = privateKeyToAccount(privateKey as `0x${string}`);
    } else {
      account = privateKeyToAccount(`0x${privateKey}` as `0x${string}`);
    }
    
    walletClient = createWalletClient({
      chain,
      transport: http(),
      account,
    });
  }
  
  return { publicClient, walletClient, account };
};

// Function to get contract balance
export const getContractBalance = async (
  network: 'optimism' | 'optimismSepolia' | 'localhost',
  contractAddress: string
) => {
  const { publicClient } = createClients(network);
  
  try {
    const balance = await publicClient.getBalance({
      address: contractAddress as `0x${string}`,
    });
    
    return balance;
  } catch (error) {
    console.error('Error getting contract balance:', error);
    throw error;
  }
};

// Function to check if a contract exists
export const checkContractExists = async (
  network: 'optimism' | 'optimismSepolia' | 'localhost',
  contractAddress: string
) => {
  const { publicClient } = createClients(network);
  
  try {
    const code = await publicClient.getBytecode({
      address: contractAddress as `0x${string}`,
    });
    
    // If the code is null or '0x', the contract doesn't exist
    return code !== null && code !== '0x';
  } catch (error) {
    console.error('Error checking if contract exists:', error);
    return false;
  }
};

// Function to deploy a contract to Optimism (would need to be implemented on the server)
export const deployContract = async (contractAbi: any, contractBytecode: string, deployArgs: any[]) => {
  // This would make a call to the server API to deploy the contract
  // Since deploying contracts requires a private key, it's better to do this on the server side
  // and return the deployed contract address to the client
  try {
    const response = await fetch('/api/deploy-contract', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contractAbi,
        contractBytecode,
        deployArgs
      }),
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    return data.contractAddress;
  } catch (error) {
    console.error('Error deploying contract:', error);
    throw error;
  }
};

// Function to send a transaction to a function on a contract
export const callContractFunction = async (
  network: 'optimism' | 'optimismSepolia' | 'localhost',
  contractAddress: string,
  contractAbi: any,
  functionName: string,
  args: any[],
  privateKey: string
) => {
  const { walletClient, account } = createClients(network, privateKey);
  
  if (!walletClient || !account) {
    throw new Error('No wallet client available. Private key is required.');
  }
  
  try {
    const hash = await walletClient.writeContract({
      address: contractAddress as `0x${string}`,
      abi: contractAbi,
      functionName,
      args,
      account, // Include the account
    });
    
    return hash;
  } catch (error) {
    console.error('Error calling contract function:', error);
    throw error;
  }
};

// Function to read data from a contract (view/pure functions)
export const readContractData = async (
  network: 'optimism' | 'optimismSepolia' | 'localhost',
  contractAddress: string,
  contractAbi: any,
  functionName: string,
  args: any[] = []
) => {
  const { publicClient } = createClients(network);
  
  try {
    const data = await publicClient.readContract({
      address: contractAddress as `0x${string}`,
      abi: contractAbi,
      functionName,
      args,
    });
    
    return data;
  } catch (error) {
    console.error('Error reading contract data:', error);
    throw error;
  }
};

// Utility function to format ETH amount
export { parseEther };