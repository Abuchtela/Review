import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TestCase } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type TestCaseCardProps = {
  testCase: TestCase;
  onEdit: (testCase: TestCase) => void;
};

export default function TestCaseCard({ testCase, onEdit }: TestCaseCardProps) {
  const [isRunning, setIsRunning] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const runTestMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/test-cases/${testCase.id}/run`, null);
      return res.json();
    },
    onMutate: () => {
      setIsRunning(true);
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/test-cases'] });
      queryClient.invalidateQueries({ queryKey: ['/api/findings'] });
      
      toast({
        title: data.result.passed ? "Test Passed" : "Test Failed",
        description: data.result.output,
        variant: data.result.passed ? "default" : "destructive",
      });
      
      setIsRunning(false);
    },
    onError: () => {
      toast({
        title: "Test Execution Failed",
        description: "There was an error running the test case. Please try again.",
        variant: "destructive",
      });
      setIsRunning(false);
    }
  });
  
  const formatDate = (date: Date | null) => {
    if (!date) return "Never";
    return new Date(date).toLocaleString();
  };

  return (
    <Card className="bg-gray-800 border-gray-700 rounded-lg overflow-hidden mb-6">
      <div className="flex items-center px-4 py-2 bg-gray-700">
        <span className="text-sm font-medium">{testCase.name}</span>
      </div>
      <div className="p-4 font-mono text-sm overflow-x-auto" style={{ backgroundColor: "#1E293B", color: "#E2E8F0" }}>
        <pre className="text-gray-300 whitespace-pre-wrap">
          {testCase.code}
        </pre>
      </div>
      <div className="flex px-4 py-3 bg-gray-700 justify-between items-center">
        <div>
          <span className="text-sm font-medium">
            Last run: <span className="text-gray-400">{formatDate(testCase.lastRun)}</span>
          </span>
          {testCase.lastRun && (
            <span className="ml-4 text-sm">
              Status: 
              {testCase.passed ? (
                <span className="text-green-400 ml-1">Passed</span>
              ) : (
                <span className="text-red-400 ml-1">Failed</span>
              )}
            </span>
          )}
        </div>
        <div className="flex space-x-2">
          <Button 
            size="sm"
            onClick={() => runTestMutation.mutate()}
            disabled={isRunning}
            className="px-3 py-1 bg-blue-600 hover:bg-blue-700"
          >
            {isRunning ? "Running..." : "Run Test"}
          </Button>
          <Button 
            size="sm"
            variant="secondary"
            onClick={() => onEdit(testCase)}
            className="px-3 py-1 bg-gray-600 hover:bg-gray-500"
          >
            Edit
          </Button>
        </div>
      </div>
    </Card>
  );
}
