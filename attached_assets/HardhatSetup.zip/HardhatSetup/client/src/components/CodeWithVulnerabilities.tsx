import React from "react";
import { VulnerabilityTooltip, VulnerabilityInfo } from "./VulnerabilityTooltip";
import { getVulnerabilityColor } from "../lib/vulnerabilityAnalyzer";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AlertTriangle, AlertCircle, AlertOctagon, Info } from "lucide-react";

// Props interface for the component
interface CodeWithVulnerabilitiesProps {
  code: string;
  vulnerabilities?: VulnerabilityInfo[];
}

// Function to get all vulnerable lines
const getAllVulnerableLines = (vulnerabilities: VulnerabilityInfo[]): number[] => {
  const allLines: number[] = [];
  
  vulnerabilities.forEach(vulnerability => {
    if (vulnerability.lineNumbers) {
      vulnerability.lineNumbers.forEach(lineNumber => {
        if (!allLines.includes(lineNumber)) {
          allLines.push(lineNumber);
        }
      });
    }
  });
  
  return allLines.sort((a, b) => a - b);
};

// Function to get vulnerabilities for a specific line
const getVulnerabilitiesForLine = (lineNumber: number, vulnerabilities: VulnerabilityInfo[]): VulnerabilityInfo[] => {
  return vulnerabilities.filter(
    vulnerability => vulnerability.lineNumbers?.includes(lineNumber)
  );
};

// CodeWithVulnerabilities component
export function CodeWithVulnerabilities({ 
  code,
  vulnerabilities = []
}: CodeWithVulnerabilitiesProps) {
  // Split code into lines for rendering
  const codeLines = code.split('\n');
  
  // Get all lines that have vulnerabilities
  const vulnerableLines = getAllVulnerableLines(vulnerabilities);
  
  // Function to get the appropriate icon based on vulnerability level
  const getVulnerabilityIcon = (level: string) => {
    const color = getVulnerabilityColor(level);
    const size = 16;
    
    switch (level) {
      case 'critical':
        return <AlertOctagon size={size} color={color} />;
      case 'high':
        return <AlertCircle size={size} color={color} />;
      case 'medium':
      case 'low':
        return <AlertTriangle size={size} color={color} />;
      case 'info':
        return <Info size={size} color={color} />;
      default:
        return null;
    }
  };
  
  // Count different types of vulnerabilities
  const criticalVulnerabilities = vulnerabilities.filter(v => v.level === 'critical').length;
  const hasVulnerabilities = vulnerabilities.length > 0;
  
  return (
    <div className="space-y-4">
      {/* Header with summary */}
      {hasVulnerabilities && (
        <div className={`text-sm p-3 rounded-md border ${
          criticalVulnerabilities > 0 ? 'border-red-400 bg-red-50' : 'border-yellow-400 bg-yellow-50'
        }`}>
          <div className="flex items-center gap-2 mb-1">
            {criticalVulnerabilities > 0 ? (
              <AlertOctagon size={16} className="text-red-500" />
            ) : (
              <AlertTriangle size={16} className="text-yellow-500" />
            )}
            <span className="font-medium">
              {criticalVulnerabilities > 0 
                ? `${criticalVulnerabilities} critical vulnerabilities detected in this code`
                : 'Vulnerabilities detected in this code'
              }
            </span>
          </div>
          <p className="text-xs text-gray-700">
            Hover over the highlighted code to see details about each vulnerability.
          </p>
        </div>
      )}
      
      {/* Code area with syntax highlighting */}
      <ScrollArea className="h-[500px] w-full rounded-md border">
        <div className="p-4 font-mono text-sm">
          <pre className="inline-block min-w-full">
            {codeLines.map((line, index) => {
              const lineNumber = index + 1;
              const lineVulnerabilities = getVulnerabilitiesForLine(lineNumber, vulnerabilities);
              const isVulnerable = vulnerableLines.includes(lineNumber);
              
              // Find the highest severity vulnerability for this line
              let highestSeverity: VulnerabilityInfo | undefined;
              
              if (isVulnerable && lineVulnerabilities.length > 0) {
                // Order of severity: critical > high > medium > low > info
                const severityOrder: Record<string, number> = {
                  critical: 4,
                  high: 3,
                  medium: 2,
                  low: 1,
                  info: 0
                };
                
                highestSeverity = lineVulnerabilities.reduce((prev, current) => {
                  return severityOrder[current.level] > severityOrder[prev.level] ? current : prev;
                }, lineVulnerabilities[0]);
              }
              
              // Style for line number column
              const lineNumberStyle = {
                display: 'inline-block',
                width: '3rem',
                textAlign: 'right' as const,
                marginRight: '1rem',
                color: '#888'
              };
              
              // Determine if this is a critical vulnerability line
              const isCritical = isVulnerable && highestSeverity?.level === 'critical';
              
              // Render the line with vulnerability highlighting if needed
              return (
                <div 
                  key={lineNumber} 
                  className={`leading-relaxed ${isVulnerable ? 'relative' : ''} ${
                    isCritical ? 'font-semibold' : ''
                  }`}
                  style={{
                    backgroundColor: isVulnerable 
                      ? `${getVulnerabilityColor(highestSeverity!.level)}${isCritical ? '33' : '22'}` // Higher opacity for critical
                      : 'transparent'
                  }}
                >
                  <span style={lineNumberStyle}>{lineNumber}</span>
                  
                  {isVulnerable && lineVulnerabilities.length > 0 ? (
                    <>
                      <VulnerabilityTooltip 
                        vulnerability={highestSeverity!}
                        className="inline cursor-pointer"
                      >
                        <span className="relative">
                          {line}
                          <span 
                            className={`absolute bottom-0 left-0 right-0 ${
                              isCritical ? 'h-1' : 'h-0.5'
                            }`}
                            style={{ 
                              backgroundColor: getVulnerabilityColor(highestSeverity!.level),
                              opacity: isCritical ? 0.7 : 0.5
                            }}
                          />
                        </span>
                      </VulnerabilityTooltip>
                      
                      {/* Vulnerability indicator with icon */}
                      <span 
                        className={`absolute right-2 top-1/2 -translate-y-1/2 flex items-center justify-center ${
                          isCritical ? 'animate-pulse' : ''
                        }`}
                      >
                        {getVulnerabilityIcon(highestSeverity!.level)}
                      </span>
                    </>
                  ) : (
                    <span>{line}</span>
                  )}
                </div>
              );
            })}
          </pre>
        </div>
      </ScrollArea>
      
      {/* Legend */}
      <div className="flex flex-wrap gap-4 text-xs mt-2">
        <div className="flex items-center gap-1">
          <AlertOctagon size={12} color={getVulnerabilityColor('critical')} />
          <span>Critical</span>
        </div>
        <div className="flex items-center gap-1">
          <AlertCircle size={12} color={getVulnerabilityColor('high')} />
          <span>High</span>
        </div>
        <div className="flex items-center gap-1">
          <AlertTriangle size={12} color={getVulnerabilityColor('medium')} />
          <span>Medium</span>
        </div>
        <div className="flex items-center gap-1">
          <AlertTriangle size={12} color={getVulnerabilityColor('low')} />
          <span>Low</span>
        </div>
        <div className="flex items-center gap-1">
          <Info size={12} color={getVulnerabilityColor('info')} />
          <span>Info</span>
        </div>
      </div>
    </div>
  );
}