import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, CheckCircle, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface OptimismContract {
  name: string;
  fileName: string;
  description: string;
  path: string;
  imported?: boolean;
}

interface ExistingContract {
  id: number;
  name: string;
  address: string;
  network: string;
  source: string;
  verified: boolean;
  dateAdded: string;
  securityScore?: number;
}

export default function OptimismContractsList() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [importedContracts, setImportedContracts] = useState<string[]>([]);

  // Fetch available contracts
  const { data: contracts = [], isLoading, error } = useQuery<OptimismContract[]>({
    queryKey: ['/api/optimism-contracts'],
    staleTime: 60000
  });

  // Fetch already imported contracts
  const { data: existingContracts = [] } = useQuery<ExistingContract[]>({
    queryKey: ['/api/contracts'],
    staleTime: 60000
  });
  
  // Update the imported contracts list whenever existingContracts changes
  useEffect(() => {
    // Check to prevent unnecessary updates that might cause infinite loops
    const importedNames = existingContracts.map((contract) => contract.name);
    
    // Only update state if the arrays are different to prevent infinite loops
    if (JSON.stringify(importedNames) !== JSON.stringify(importedContracts)) {
      setImportedContracts(importedNames);
    }
  }, [existingContracts, importedContracts]);

  // Import contract mutation
  const importMutation = useMutation({
    mutationFn: async (fileName: string) => {
      const response = await fetch('/api/optimism-contracts/import', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ fileName }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to import contract');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      // Invalidate and refetch contracts
      queryClient.invalidateQueries({ queryKey: ['/api/contracts'] });
      
      // Add to local imported contracts list
      setImportedContracts(prev => [...prev, data.name]);
      
      toast({
        title: 'Contract Imported',
        description: `${data.name} has been successfully imported.`,
        variant: 'default',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Import Failed',
        description: error.message,
        variant: 'destructive',
      });
    }
  });

  const handleImport = (fileName: string) => {
    importMutation.mutate(fileName);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Loading contracts...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
        <strong className="font-bold">Error!</strong>
        <span className="block sm:inline"> Failed to load Optimism contracts.</span>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
      {contracts?.map((contract: OptimismContract) => {
        const isImported = importedContracts.includes(contract.name);
        
        return (
          <Card key={contract.fileName} className="overflow-hidden">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-xl font-bold">{contract.name}</CardTitle>
                {isImported && (
                  <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Imported
                  </Badge>
                )}
              </div>
              <CardDescription className="text-sm text-muted-foreground line-clamp-2">
                {contract.description || "Optimism contract"}
              </CardDescription>
            </CardHeader>
            
            <CardContent className="pt-2">
              <div className="text-sm text-muted-foreground">
                <p>File: {contract.fileName}</p>
              </div>
            </CardContent>
            
            <CardFooter>
              <Button
                onClick={() => handleImport(contract.fileName)}
                disabled={isImported || importMutation.isPending}
                variant={isImported ? "outline" : "default"}
                className="w-full"
              >
                {importMutation.isPending && importMutation.variables === contract.fileName ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Importing...
                  </>
                ) : isImported ? (
                  <>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Already Imported
                  </>
                ) : (
                  'Import Contract'
                )}
              </Button>
            </CardFooter>
          </Card>
        );
      })}
      
      {contracts?.length === 0 && (
        <div className="col-span-full flex flex-col items-center justify-center p-8 bg-muted rounded-lg">
          <AlertTriangle className="h-12 w-12 text-amber-500 mb-4" />
          <h3 className="text-xl font-medium mb-2">No Optimism Contracts Found</h3>
          <p className="text-center text-muted-foreground">
            No Optimism contracts were found in the contracts directory.
          </p>
        </div>
      )}
    </div>
  );
}