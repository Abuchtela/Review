import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

type ConfigFileCardProps = {
  fileName: string;
  code: string;
  onSave?: (code: string) => void;
};

export default function ConfigFileCard({ fileName, code, onSave }: ConfigFileCardProps) {
  const [configCode, setConfigCode] = useState(code);
  const [isEditing, setIsEditing] = useState(false);

  const handleSave = () => {
    if (onSave) {
      onSave(configCode);
    }
    setIsEditing(false);
  };

  return (
    <Card className="bg-gray-800 border-gray-700 rounded-lg overflow-hidden mb-4">
      <div className="flex items-center px-4 py-2 bg-gray-700">
        <span className="text-sm font-medium">{fileName}</span>
      </div>
      <div className="p-4">
        {isEditing ? (
          <textarea 
            value={configCode}
            onChange={(e) => setConfigCode(e.target.value)}
            className="w-full h-64 p-2 bg-gray-900 text-gray-300 font-mono text-sm rounded-md border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
        ) : (
          <pre className="p-2 bg-gray-900 text-gray-300 font-mono text-sm rounded-md overflow-x-auto whitespace-pre-wrap">
            {configCode}
          </pre>
        )}
      </div>
      <div className="flex justify-end px-4 py-2 bg-gray-700">
        {isEditing ? (
          <>
            <Button 
              variant="ghost" 
              onClick={() => setIsEditing(false)}
              className="mr-2"
            >
              Cancel
            </Button>
            <Button onClick={handleSave}>
              Save Changes
            </Button>
          </>
        ) : (
          <Button onClick={() => setIsEditing(true)}>
            Edit Configuration
          </Button>
        )}
      </div>
    </Card>
  );
}
