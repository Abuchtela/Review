import React from "react";

type TerminalOutputProps = {
  output: string[];
  isLoading?: boolean;
  className?: string;
};

export default function TerminalOutput({ 
  output, 
  isLoading = false,
  className = ""
}: TerminalOutputProps) {
  const terminalRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [output]);

  return (
    <div 
      ref={terminalRef}
      className={`bg-terminal-bg rounded-md p-3 font-mono text-sm text-terminal-text overflow-x-auto ${className}`}
      style={{ 
        backgroundColor: "#1E293B", 
        color: "#E2E8F0",
        maxHeight: "300px",
        overflowY: "auto"
      }}
    >
      {output.map((line, index) => (
        <div key={index} className={line.startsWith("$") ? "text-green-400" : ""}>
          {line.startsWith("Error:") ? (
            <span className="text-red-400">{line}</span>
          ) : line.startsWith("Warning:") ? (
            <span className="text-yellow-400">{line}</span>
          ) : line.startsWith("Success:") ? (
            <span className="text-green-400">{line}</span>
          ) : (
            line
          )}
        </div>
      ))}
      {isLoading && (
        <div className="flex items-center mt-1">
          <div className="animate-pulse text-blue-400">▌</div>
        </div>
      )}
    </div>
  );
}
