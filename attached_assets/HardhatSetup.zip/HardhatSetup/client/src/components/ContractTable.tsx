import React from "react";
import { Contract } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Search, Eye, Shield, MoreHorizontal } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

// Define component props
type ContractTableProps = {
  contracts: Contract[];
  onAnalyze: (contract: Contract) => void;
  onView: (contract: Contract) => void;
};

// ContractTable component
export default function ContractTable({ contracts, onAnalyze, onView }: ContractTableProps) {
  return (
    <Card className="w-full shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Imported Contracts</span>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <input
                type="text"
                placeholder="Search contracts..."
                className="pl-8 h-9 w-[250px] rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm"
              />
            </div>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {contracts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center text-gray-500">
            <Shield className="h-12 w-12 mb-4 opacity-20" />
            <h3 className="text-lg font-medium mb-1">No Contracts Imported</h3>
            <p className="text-sm max-w-md mb-6">
              Import smart contracts to analyze them for security vulnerabilities.
            </p>
            <Button>Import Contract</Button>
          </div>
        ) : (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Address</TableHead>
                  <TableHead>Network</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {contracts.map((contract) => (
                  <TableRow key={contract.id}>
                    <TableCell className="font-medium">{contract.name}</TableCell>
                    <TableCell className="font-mono text-xs">
                      {contract.address.substring(0, 8)}...{contract.address.substring(contract.address.length - 6)}
                    </TableCell>
                    <TableCell>
                      <span className="inline-flex items-center rounded-full bg-purple-100 px-2.5 py-0.5 text-xs font-medium text-purple-800">
                        {contract.network}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span 
                        className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                          contract.verified 
                            ? "bg-green-100 text-green-800" 
                            : "bg-amber-100 text-amber-800"
                        }`}
                      >
                        {contract.verified ? "Verified" : "Unverified"}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button size="sm" variant="outline" onClick={() => onView(contract)}>
                          <Eye className="h-4 w-4" />
                          <span className="sr-only">View</span>
                        </Button>
                        <Button size="sm" onClick={() => onAnalyze(contract)}>
                          <Shield className="h-4 w-4" />
                          <span className="ml-2">Analyze</span>
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button size="sm" variant="ghost">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">More</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>Copy Address</DropdownMenuItem>
                            <DropdownMenuItem>Export Report</DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600">Delete Contract</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}