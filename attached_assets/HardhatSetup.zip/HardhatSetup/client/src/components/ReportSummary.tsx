import { Card } from "@/components/ui/card";
import { AlertTriangle, AlertCircle, Info, AlertOctagon, LockIcon, TrendingDown, Zap } from "lucide-react";
import { Finding } from "@shared/schema";
import { Badge } from "@/components/ui/badge";

type ReportSummaryProps = {
  criticalCount: number;
  highCount: number;
  mediumCount: number;
  lowCount: number;
  findings: Finding[];
};

// Function to get the appropriate icon based on the finding title
const getIconForFinding = (title: string, severity: string) => {
  // Critical severity icons
  if (title.includes("theft") || title.includes("steal")) {
    return <AlertOctagon className="h-5 w-5 mr-2 text-red-500" />;
  } else if (title.includes("freezing") || title.includes("frozen") || title.includes("lock")) {
    return <LockIcon className="h-5 w-5 mr-2 text-red-500" />;
  } else if (title.includes("insolvency") || title.includes("insolvent")) {
    return <TrendingDown className="h-5 w-5 mr-2 text-red-500" />;
  } 
  // High severity icons
  else if (title.includes("dispute game") || title.includes("incorrectly resolved")) {
    return <Zap className="h-5 w-5 mr-2 text-orange-500" />;
  } else if (title.includes("withdrawal")) {
    return <AlertTriangle className="h-5 w-5 mr-2 text-orange-500" />;
  }
  // Default icons based on severity
  else if (severity === "critical") {
    return <AlertCircle className="h-5 w-5 mr-2 text-red-500" />;
  } else if (severity === "high") {
    return <AlertTriangle className="h-5 w-5 mr-2 text-orange-500" />;
  } else if (severity === "medium") {
    return <AlertTriangle className="h-5 w-5 mr-2 text-yellow-500" />;
  } else {
    return <Info className="h-5 w-5 mr-2 text-blue-400" />;
  }
};

// Group findings by severity
const groupFindingsBySeverity = (findings: Finding[]) => {
  return {
    critical: findings.filter(f => f.severity === "critical"),
    high: findings.filter(f => f.severity === "high"),
    medium: findings.filter(f => f.severity === "medium"),
    low: findings.filter(f => f.severity === "low")
  };
};

export default function ReportSummary({ 
  criticalCount,
  highCount, 
  mediumCount, 
  lowCount,
  findings
}: ReportSummaryProps) {
  const groupedFindings = groupFindingsBySeverity(findings);
  
  return (
    <div className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden">
      <div className="p-5">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-5 mb-6">
          <div className="bg-gray-700 rounded-lg p-4">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="text-sm font-medium text-gray-300">Critical Issues</h3>
                <p className="text-2xl font-bold text-red-500">{criticalCount}</p>
              </div>
              <div className="p-2 bg-red-900 bg-opacity-20 rounded-md">
                <AlertCircle className="h-6 w-6 text-red-500" />
              </div>
            </div>
            <p className="text-xs text-gray-400">
              {criticalCount === 0 
                ? "No critical security vulnerabilities found" 
                : `${criticalCount} critical issues need immediate attention`}
            </p>
          </div>
          <div className="bg-gray-700 rounded-lg p-4">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="text-sm font-medium text-gray-300">High Issues</h3>
                <p className="text-2xl font-bold text-orange-500">{highCount}</p>
              </div>
              <div className="p-2 bg-orange-900 bg-opacity-20 rounded-md">
                <AlertTriangle className="h-6 w-6 text-orange-500" />
              </div>
            </div>
            <p className="text-xs text-gray-400">
              {highCount === 0 
                ? "No high severity issues found" 
                : `${highCount} high impact issues to address`}
            </p>
          </div>
          <div className="bg-gray-700 rounded-lg p-4">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="text-sm font-medium text-gray-300">Medium Issues</h3>
                <p className="text-2xl font-bold text-yellow-500">{mediumCount}</p>
              </div>
              <div className="p-2 bg-yellow-900 bg-opacity-20 rounded-md">
                <AlertTriangle className="h-6 w-6 text-yellow-500" />
              </div>
            </div>
            <p className="text-xs text-gray-400">
              {mediumCount === 0 
                ? "No medium risk issues found" 
                : `${mediumCount} medium risk issues to review`}
            </p>
          </div>
          <div className="bg-gray-700 rounded-lg p-4">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="text-sm font-medium text-gray-300">Low Issues</h3>
                <p className="text-2xl font-bold text-blue-400">{lowCount}</p>
              </div>
              <div className="p-2 bg-blue-900 bg-opacity-20 rounded-md">
                <Info className="h-6 w-6 text-blue-400" />
              </div>
            </div>
            <p className="text-xs text-gray-400">
              {lowCount === 0 
                ? "No low severity issues found" 
                : "Minor issues with low impact on security"}
            </p>
          </div>
        </div>

        {findings.length > 0 && (
          <div className="mb-6">
            <h3 className="text-sm font-medium text-gray-300 mb-3">Security Analysis Overview</h3>
            <div className="bg-gray-700 rounded-lg p-4 text-sm">
              <p className="mb-3 text-gray-300">
                Our Optimism-specific security analysis has identified the following issues that 
                may affect the security of your contracts:
              </p>
              
              {/* Categorized findings summary */}
              <div className="space-y-4">
                {criticalCount > 0 && (
                  <div className="border-l-4 border-red-500 pl-3">
                    <h4 className="font-medium text-red-400 mb-1">Critical Vulnerabilities:</h4>
                    <ul className="list-disc pl-5 space-y-1 text-gray-300">
                      {groupedFindings.critical.map((finding) => (
                        <li key={finding.id}>
                          {finding.title}
                          <Badge variant="outline" className="ml-2 bg-red-900 bg-opacity-30 text-red-400 text-xs">
                            Critical
                          </Badge>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {highCount > 0 && (
                  <div className="border-l-4 border-orange-500 pl-3">
                    <h4 className="font-medium text-orange-400 mb-1">High Impact Issues:</h4>
                    <ul className="list-disc pl-5 space-y-1 text-gray-300">
                      {groupedFindings.high.map((finding) => (
                        <li key={finding.id}>
                          {finding.title}
                          <Badge variant="outline" className="ml-2 bg-orange-900 bg-opacity-30 text-orange-400 text-xs">
                            High
                          </Badge>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {mediumCount > 0 && (
                  <div className="border-l-4 border-yellow-500 pl-3">
                    <h4 className="font-medium text-yellow-400 mb-1">Medium Risk Issues:</h4>
                    <ul className="list-disc pl-5 space-y-1 text-gray-300">
                      {groupedFindings.medium.map((finding) => (
                        <li key={finding.id}>
                          {finding.title}
                          <Badge variant="outline" className="ml-2 bg-yellow-900 bg-opacity-30 text-yellow-400 text-xs">
                            Medium
                          </Badge>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {lowCount > 0 && (
                  <div className="border-l-4 border-blue-400 pl-3">
                    <h4 className="font-medium text-blue-400 mb-1">Low Severity Issues:</h4>
                    <ul className="list-disc pl-5 space-y-1 text-gray-300">
                      {groupedFindings.low.map((finding) => (
                        <li key={finding.id}>
                          {finding.title}
                          <Badge variant="outline" className="ml-2 bg-blue-900 bg-opacity-30 text-blue-400 text-xs">
                            Low
                          </Badge>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {findings.length > 0 && (
          <div>
            <h3 className="text-sm font-medium text-gray-300 mb-3">Detailed Findings & Recommendations</h3>
            <div className="space-y-4">
              {/* Critical findings first */}
              {groupedFindings.critical.length > 0 && (
                <>
                  <h4 className="font-medium text-red-400 mb-2 border-b border-gray-700 pb-1">Critical Vulnerabilities</h4>
                  {groupedFindings.critical.map((finding) => (
                    <div key={finding.id} className="bg-gray-700 rounded-lg p-4 mb-3 text-sm">
                      <div className="flex items-center mb-2">
                        {getIconForFinding(finding.title, finding.severity)}
                        <h4 className="font-medium text-gray-300">{finding.title}</h4>
                      </div>
                      <p className="text-gray-400 mb-3">{finding.description}</p>
                      {finding.recommendation && (
                        <div className="bg-gray-800 rounded p-3 font-mono text-xs">
                          <p className="text-yellow-400 mb-1">// Recommendation</p>
                          <p className="text-green-400">{finding.recommendation}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </>
              )}

              {/* High findings */}
              {groupedFindings.high.length > 0 && (
                <>
                  <h4 className="font-medium text-orange-400 mb-2 border-b border-gray-700 pb-1">High Impact Issues</h4>
                  {groupedFindings.high.map((finding) => (
                    <div key={finding.id} className="bg-gray-700 rounded-lg p-4 mb-3 text-sm">
                      <div className="flex items-center mb-2">
                        {getIconForFinding(finding.title, finding.severity)}
                        <h4 className="font-medium text-gray-300">{finding.title}</h4>
                      </div>
                      <p className="text-gray-400 mb-3">{finding.description}</p>
                      {finding.recommendation && (
                        <div className="bg-gray-800 rounded p-3 font-mono text-xs">
                          <p className="text-yellow-400 mb-1">// Recommendation</p>
                          <p className="text-green-400">{finding.recommendation}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </>
              )}

              {/* Medium findings */}
              {groupedFindings.medium.length > 0 && (
                <>
                  <h4 className="font-medium text-yellow-400 mb-2 border-b border-gray-700 pb-1">Medium Risk Issues</h4>
                  {groupedFindings.medium.map((finding) => (
                    <div key={finding.id} className="bg-gray-700 rounded-lg p-4 mb-3 text-sm">
                      <div className="flex items-center mb-2">
                        {getIconForFinding(finding.title, finding.severity)}
                        <h4 className="font-medium text-gray-300">{finding.title}</h4>
                      </div>
                      <p className="text-gray-400 mb-3">{finding.description}</p>
                      {finding.recommendation && (
                        <div className="bg-gray-800 rounded p-3 font-mono text-xs">
                          <p className="text-yellow-400 mb-1">// Recommendation</p>
                          <p className="text-green-400">{finding.recommendation}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </>
              )}

              {/* Low findings */}
              {groupedFindings.low.length > 0 && (
                <>
                  <h4 className="font-medium text-blue-400 mb-2 border-b border-gray-700 pb-1">Low Severity Issues</h4>
                  {groupedFindings.low.map((finding) => (
                    <div key={finding.id} className="bg-gray-700 rounded-lg p-4 mb-3 text-sm">
                      <div className="flex items-center mb-2">
                        {getIconForFinding(finding.title, finding.severity)}
                        <h4 className="font-medium text-gray-300">{finding.title}</h4>
                      </div>
                      <p className="text-gray-400 mb-3">{finding.description}</p>
                      {finding.recommendation && (
                        <div className="bg-gray-800 rounded p-3 font-mono text-xs">
                          <p className="text-yellow-400 mb-1">// Recommendation</p>
                          <p className="text-green-400">{finding.recommendation}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
