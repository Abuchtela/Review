import { Shield } from "lucide-react";

type HeaderProps = {
  toggleSidebar: () => void;
};

export default function Header({ toggleSidebar }: HeaderProps) {
  return (
    <header className="bg-gray-800 border-b border-gray-700">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <button 
            onClick={toggleSidebar}
            className="md:hidden mr-2"
            aria-label="Toggle sidebar"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </button>
          <Shield className="h-8 w-8 text-red-500" />
          <h1 className="text-xl font-semibold">Optimism Security Testing Suite</h1>
        </div>
        <div className="flex items-center space-x-4">
          <button className="px-3 py-1 bg-blue-600 hover:bg-blue-700 rounded text-sm font-medium transition">
            Documentation
          </button>
          <button className="px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-sm font-medium transition">
            Settings
          </button>
        </div>
      </div>
    </header>
  );
}
