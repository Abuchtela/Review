import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { analyzeContract, deepAnalyzeContract } from "@/lib/vulnerabilityAnalyzer";
import ReportSummary from "@/components/ReportSummary";
import { Card } from "@/components/ui/card";
import { Finding } from "@shared/schema";
import Link from "next/link";

export default function Reports() {
  const [generatingReport, setGeneratingReport] = useState(false);
  const { toast } = useToast();

  // Fetch findings
  const { 
    data: findings = [] as Finding[],
    isLoading,
    refetch: refetchFindings
  } = useQuery<Finding[]>({
    queryKey: ['/api/findings'],
    staleTime: 60000 // 1 minute
  });

  // Generate report mutation
  const generateReportMutation = useMutation({
    mutationFn: async (results: any) => {
      const res = await apiRequest("POST", "/api/reports/generate", results);
      return res.json();
    },
    onMutate: () => {
      setGeneratingReport(true);
    },
    onSuccess: (data) => {
      setGeneratingReport(false);
      refetchFindings();
      toast({
        title: "Report Generated",
        description: "Security report has been generated successfully.",
      });
    },
    onError: () => {
      setGeneratingReport(false);
      toast({
        title: "Report Generation Failed",
        description: "Failed to generate the security report. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Count findings by severity
  const criticalCount = findings.filter((f: Finding) => f.severity === "critical").length;
  const highCount = findings.filter((f: Finding) => f.severity === "high").length;
  const mediumCount = findings.filter((f: Finding) => f.severity === "medium").length;
  const lowCount = findings.filter((f: Finding) => f.severity === "low").length;

  // Get all files from the contracts directory
  const { data: contracts = [] } = useQuery({
    queryKey: ['/api/contracts'],
    select: (data) => data.map((contract: any) => contract.name)
  });

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Security Report</h1>
        <div className="flex gap-2">
          <Button 
            onClick={async () => {
              try {

                // Import the contracts first via API
                for (const contract of contracts) {
                  const source = await fetch(`/contracts/${contract}`).then(r => r.text());
                  await apiRequest("POST", "/api/contracts/import", {
                    name: contract,
                    source,
                    address: "0x0000000000000000000000000000000000000000",
                    network: "optimism"
                  });
                }

                // Now analyze the imported contracts
                const analysisResults = await Promise.all(
                  contracts.map(async (contract) => {
                    const source = await fetch(`/contracts/${contract}`).then(r => r.text());
                    return {
                      contract,
                      findings: analyzeContract(source),
                      deepFindings: deepAnalyzeContract(source)
                    };
                  })
                );

                generateReportMutation.mutate(analysisResults);
              } catch (error) {
                toast({
                  title: "Analysis Failed",
                  description: "Failed to analyze contracts. Please ensure all contracts are imported.",
                  variant: "destructive"
                });
              }
            }}
            disabled={generatingReport}
          >
            {generatingReport ? "Generating..." : "Generate Full Report"}
          </Button>
          <Button
            onClick={() => {
              const report = {
                timestamp: new Date().toISOString(),
                findings: findings,
                summary: {
                  critical: criticalCount,
                  high: highCount,
                  medium: mediumCount,
                  low: lowCount,
                  total: findings.length
                }
              };

              const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `vulnerability-analysis-${new Date().toISOString()}.json`;
              document.body.appendChild(a);
              a.click();
              URL.revokeObjectURL(url);
              document.body.removeChild(a);

              toast({
                title: "Analysis Downloaded",
                description: "Vulnerability analysis has been downloaded successfully.",
              });
            }}
            variant="outline"
            disabled={findings.length === 0}
          >
            Download Analysis
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-10">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>Loading security findings...</p>
        </div>
      ) : findings.length === 0 ? (
        <Card className="bg-gray-800 border-gray-700 p-8 text-center">
          <h3 className="text-xl font-medium mb-2">No Security Findings Yet</h3>
          <p className="text-gray-400 mb-6">
            Run security tests on your contracts to identify vulnerabilities and generate a comprehensive security report.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-5 mb-6">
            <div className="bg-gray-700 rounded-lg p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="text-sm font-medium text-gray-300">Critical Issues</h3>
                  <p className="text-2xl font-bold text-green-500">0</p>
                </div>
                <div className="p-2 bg-green-900 bg-opacity-20 rounded-md">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <p className="text-xs text-gray-400">No critical security vulnerabilities found</p>
            </div>
            <div className="bg-gray-700 rounded-lg p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="text-sm font-medium text-gray-300">High Issues</h3>
                  <p className="text-2xl font-bold text-green-500">0</p>
                </div>
                <div className="p-2 bg-green-900 bg-opacity-20 rounded-md">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <p className="text-xs text-gray-400">No high severity issues found</p>
            </div>
            <div className="bg-gray-700 rounded-lg p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="text-sm font-medium text-gray-300">Medium Issues</h3>
                  <p className="text-2xl font-bold text-green-500">0</p>
                </div>
                <div className="p-2 bg-green-900 bg-opacity-20 rounded-md">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <p className="text-xs text-gray-400">No medium risk issues found</p>
            </div>
            <div className="bg-gray-700 rounded-lg p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="text-sm font-medium text-gray-300">Low Issues</h3>
                  <p className="text-2xl font-bold text-green-500">0</p>
                </div>
                <div className="p-2 bg-green-900 bg-opacity-20 rounded-md">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <p className="text-xs text-gray-400">No low severity issues found</p>
            </div>
          </div>
          <Button
            onClick={async () => {
              try {

                // Import the contracts first via API
                for (const contract of contracts) {
                  const source = await fetch(`/contracts/${contract}`).then(r => r.text());
                  await apiRequest("POST", "/api/contracts/import", {
                    name: contract,
                    source,
                    address: "0x0000000000000000000000000000000000000000",
                    network: "optimism"
                  });
                }

                // Now analyze the imported contracts
                const analysisResults = await Promise.all(
                  contracts.map(async (contract) => {
                    const source = await fetch(`/contracts/${contract}`).then(r => r.text());
                    return {
                      contract,
                      findings: analyzeContract(source),
                      deepFindings: deepAnalyzeContract(source)
                    };
                  })
                );

                generateReportMutation.mutate(analysisResults);
              } catch (error) {
                toast({
                  title: "Analysis Failed",
                  description: "Failed to analyze contracts. Please ensure all contracts are imported.",
                  variant: "destructive"
                });
              }
            }}
            disabled={generatingReport}
          >
            Run Security Analysis
          </Button>
        </Card>
      ) : (
        <ReportSummary
          criticalCount={criticalCount}
          highCount={highCount}
          mediumCount={mediumCount}
          lowCount={lowCount}
          findings={findings}
        />
      )}
    </div>
  );
}