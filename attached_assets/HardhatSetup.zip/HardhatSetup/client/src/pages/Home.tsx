import { useEffect, useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Shield, ArrowRight } from "lucide-react";
import { setupHardhatEnvironment } from "@/lib/hardhatUtils";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const [isSettingUp, setIsSettingUp] = useState(false);
  const { toast } = useToast();
  
  const handleQuickSetup = async () => {
    setIsSettingUp(true);
    try {
      await setupHardhatEnvironment();
      toast({
        title: "Setup Complete",
        description: "Hardhat environment has been set up successfully!",
      });
      setIsSettingUp(false);
    } catch (error) {
      toast({
        title: "Setup Failed",
        description: "Failed to set up the Hardhat environment. Please try again.",
        variant: "destructive",
      });
      setIsSettingUp(false);
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Optimism Smart Contract Security Testing Suite</h1>
        <p className="text-gray-400 text-lg mb-6">
          Analyze and identify vulnerabilities in Optimism's Layer 2 smart contracts with our comprehensive security testing framework.
        </p>
        <div className="flex flex-wrap gap-4">
          <Link href="/environment-setup" className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md font-medium transition-colors">
            Get Started
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
          <Button 
            onClick={handleQuickSetup} 
            disabled={isSettingUp}
            className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-md font-medium transition-colors"
          >
            {isSettingUp ? "Setting up..." : "Quick Setup"}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-6">
          <div className="bg-blue-900 bg-opacity-20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <Shield className="h-6 w-6 text-blue-400" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Comprehensive Analysis</h3>
          <p className="text-gray-400">
            Automatically scan your smart contracts for vulnerabilities using industry-standard tools like Slither, Mythril, and Echidna.
          </p>
        </div>
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-6">
          <div className="bg-purple-900 bg-opacity-20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
            </svg>
          </div>
          <h3 className="text-lg font-semibold mb-2">Optimism Layer 2 Focused</h3>
          <p className="text-gray-400">
            Specialized security tests for Optimism's Layer 2 specific vulnerabilities and unique smart contract patterns.
          </p>
        </div>
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-6">
          <div className="bg-green-900 bg-opacity-20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h3 className="text-lg font-semibold mb-2">Detailed Reports</h3>
          <p className="text-gray-400">
            Generate comprehensive security reports with detailed findings, severity ratings, and actionable recommendations.
          </p>
        </div>
      </div>

      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Getting Started Guide</h2>
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-6">
          <ol className="list-decimal pl-5 space-y-4 text-gray-300">
            <li>
              <strong className="text-white">Environment Setup</strong> - Configure Hardhat with Optimism settings and install security testing plugins
            </li>
            <li>
              <strong className="text-white">Import Contracts</strong> - Add your Optimism smart contracts for analysis
            </li>
            <li>
              <strong className="text-white">Select Tools</strong> - Choose which security analysis tools to run
            </li>
            <li>
              <strong className="text-white">Run Tests</strong> - Execute vulnerability tests against your contracts
            </li>
            <li>
              <strong className="text-white">Review Reports</strong> - Analyze findings and implement recommended security improvements
            </li>
          </ol>
        </div>
      </div>
    </div>
  );
}
