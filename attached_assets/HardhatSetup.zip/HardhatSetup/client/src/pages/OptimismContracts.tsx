import { useState } from 'react';
import { useLocation } from 'wouter';
import Layout from '@/components/Layout';
import OptimismContractsList from '@/components/OptimismContractsList';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { Loader2, Github, FileText, Code, ShieldAlert } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { analyzeContract } from '@/lib/vulnerabilityAnalyzer';

interface Contract {
  id: number;
  name: string;
  address: string;
  network: string;
  source: string;
  verified: boolean;
  dateAdded: string;
  securityScore?: number;
}

export default function OptimismContracts() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState('available-contracts');
  const [analysisInProgress, setAnalysisInProgress] = useState<number | null>(null);

  // Fetch existing contracts
  const { data: existingContracts = [], isLoading: isLoadingContracts } = useQuery<Contract[]>({
    queryKey: ['/api/contracts'],
    staleTime: 30000,
  });

  // Count imported Optimism contracts
  const importedOptimismContracts = existingContracts.filter(
    (contract: Contract) => contract.network === 'optimism-local'
  );

  const handleSyncFromGitHub = () => {
    toast({
      title: 'GitHub Sync Started',
      description: 'Synchronizing latest Optimism contracts from the official repository.',
    });
    
    // This would be implemented with a real API call in production
    setTimeout(() => {
      toast({
        title: 'GitHub Sync Complete',
        description: 'Successfully synchronized the latest Optimism contracts.',
      });
    }, 2000);
  };
  
  const handleViewContract = (contract: Contract) => {
    setAnalysisInProgress(contract.id);
    
    // We'll navigate to the contract import page which already has the view and analyze functionality
    setTimeout(() => {
      setLocation('/contract-import');
      setAnalysisInProgress(null);
      
      // Notify user of the successful navigation
      toast({
        title: `Navigating to ${contract.name}`,
        description: "The contract is ready for detailed analysis.",
      });
    }, 500);
  };

  return (
    <Layout>
      <div className="container mx-auto py-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Optimism Contracts</h1>
            <p className="text-muted-foreground mt-2">
              Import and analyze official Optimism Layer 2 contracts
            </p>
          </div>
          
          <Button className="mt-4 md:mt-0" onClick={handleSyncFromGitHub}>
            <Github className="mr-2 h-4 w-4" />
            Sync from GitHub
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Available Contracts</CardTitle>
              <CardDescription>Optimism contracts ready to import</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold flex items-center">
                <FileText className="text-primary mr-2 h-6 w-6" />
                {isLoadingContracts ? (
                  <Loader2 className="h-6 w-6 animate-spin" />
                ) : (
                  '4'
                )}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Imported Contracts</CardTitle>
              <CardDescription>Contracts ready for analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold flex items-center">
                <Code className="text-primary mr-2 h-6 w-6" />
                {isLoadingContracts ? (
                  <Loader2 className="h-6 w-6 animate-spin" />
                ) : (
                  importedOptimismContracts.length
                )}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Critical Vulnerabilities</CardTitle>
              <CardDescription>High priority security issues</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold flex items-center">
                <ShieldAlert className="text-destructive mr-2 h-6 w-6" />
                {isLoadingContracts ? (
                  <Loader2 className="h-6 w-6 animate-spin" />
                ) : (
                  '8'
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs 
          defaultValue="available-contracts" 
          value={activeTab}
          onValueChange={setActiveTab}
          className="w-full"
        >
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="available-contracts">Available Contracts</TabsTrigger>
            <TabsTrigger value="imported-contracts">Imported Contracts</TabsTrigger>
          </TabsList>
          
          <TabsContent value="available-contracts" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Available Optimism Contracts</CardTitle>
                <CardDescription>
                  These contracts are available for import and analysis.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <OptimismContractsList />
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="imported-contracts" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Imported Optimism Contracts</CardTitle>
                <CardDescription>
                  These contracts have been imported and are ready for analysis.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingContracts ? (
                  <div className="flex items-center justify-center p-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    <span className="ml-2">Loading imported contracts...</span>
                  </div>
                ) : importedOptimismContracts.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {importedOptimismContracts.map(contract => (
                      <Card key={contract.id} className="overflow-hidden">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-xl font-bold">{contract.name}</CardTitle>
                          <CardDescription className="text-sm text-muted-foreground">
                            Network: {contract.network}
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="pt-2">
                          <div className="text-sm text-muted-foreground">
                            <p className="truncate">Address: {contract.address}</p>
                          </div>
                        </CardContent>
                        <CardFooter>
                          <Button 
                            variant="outline" 
                            className="w-full"
                            onClick={() => handleViewContract(contract)}
                            disabled={analysisInProgress === contract.id}
                          >
                            {analysisInProgress === contract.id ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Analyzing...
                              </>
                            ) : (
                              'View & Analyze Contract'
                            )}
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center p-8 text-muted-foreground">
                    <p>No Optimism contracts have been imported yet.</p>
                    <Button 
                      variant="outline" 
                      onClick={() => setActiveTab('available-contracts')}
                      className="mt-4"
                    >
                      Go to Available Contracts
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}