import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import SecurityToolCard from "@/components/SecurityToolCard";
import { SecurityTool } from "@shared/schema";

export default function SecurityTools() {
  // Fetch security tools
  const { data: securityTools = [], isLoading } = useQuery<SecurityTool[]>({
    queryKey: ['/api/security-tools'],
    staleTime: 60000 // 1 minute
  });

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Security Analysis Tools</h1>
        <p className="text-gray-400 mb-4">
          Install and configure security analysis tools to scan your Optimism smart contracts for vulnerabilities.
        </p>
      </div>

      {isLoading ? (
        <div className="text-center py-10">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>Loading security tools...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {securityTools.map(tool => (
            <SecurityToolCard key={tool.id} tool={tool} />
          ))}
        </div>
      )}

      <div className="flex justify-end space-x-4 mt-8">
        <Button 
          variant="outline"
          className="bg-gray-700 hover:bg-gray-600 text-white"
          onClick={() => window.location.href = '/environment-setup'}
        >
          Back to Setup
        </Button>
        <Button 
          variant="default"
          className="bg-blue-600 hover:bg-blue-700 text-white"
          onClick={() => window.location.href = '/test-cases'}
        >
          Next: Test Cases
        </Button>
      </div>
    </div>
  );
}
