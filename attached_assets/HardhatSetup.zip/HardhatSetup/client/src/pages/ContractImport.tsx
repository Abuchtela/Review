import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import ContractTable from "@/components/ContractTable";
import { apiRequest } from "@/lib/queryClient";
import { Contract } from "@shared/schema";
import { sampleContracts } from "@/lib/hardhatUtils";
import { ContractVulnerabilityView } from "@/components/ContractVulnerabilityView";

export default function ContractImport() {
  const [open, setOpen] = useState(false);
  const [contractDetails, setContractDetails] = useState({
    name: "",
    address: "",
    source: "",
    network: "optimism"
  });
  const [viewingContract, setViewingContract] = useState<Contract | null>(null);
  const [viewOpen, setViewOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch contracts
  const { data, isLoading } = useQuery<Contract[]>({
    queryKey: ['/api/contracts'],
    staleTime: 60000 // 1 minute
  });
  
  // Handle undefined data with a default empty array
  const contracts: Contract[] = data || [];

  // Add contract mutation
  const addContractMutation = useMutation({
    mutationFn: async (contractData: typeof contractDetails) => {
      const res = await apiRequest("POST", "/api/contracts", contractData);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/contracts'] });
      setOpen(false);
      setContractDetails({
        name: "",
        address: "",
        source: "",
        network: "optimism"
      });
      toast({
        title: "Contract Imported",
        description: "The smart contract has been successfully imported for analysis.",
      });
      // Open the contract immediately for viewing and analysis
      setViewingContract(data);
      setViewOpen(true);
    },
    onError: () => {
      toast({
        title: "Import Failed",
        description: "Failed to import the contract. Please check the details and try again.",
        variant: "destructive",
      });
    }
  });

  // Import sample contracts mutation
  const importSamplesMutation = useMutation({
    mutationFn: async () => {
      // Import each sample contract in sequence
      for (const contract of sampleContracts) {
        await apiRequest("POST", "/api/contracts", contract);
      }
      return { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/contracts'] });
      toast({
        title: "Sample Contracts Imported",
        description: "Sample Optimism contracts have been imported for analysis.",
      });
    },
    onError: () => {
      toast({
        title: "Import Failed",
        description: "Failed to import sample contracts. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addContractMutation.mutate(contractDetails);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setContractDetails(prev => ({ ...prev, [name]: value }));
  };

  const handleAnalyze = (contract: Contract) => {
    // This function will be implemented to start the security analysis
    setViewingContract(contract);
    setViewOpen(true);
  };

  const handleView = (contract: Contract) => {
    setViewingContract(contract);
    setViewOpen(true);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
          Optimism Smart Contracts
        </h1>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            onClick={() => importSamplesMutation.mutate()}
            disabled={importSamplesMutation.isPending}
          >
            {importSamplesMutation.isPending ? "Importing..." : "Import Samples"}
          </Button>
          <Button onClick={() => setOpen(true)}>
            Import New Contract
          </Button>
        </div>
      </div>

      {/* Contract Table */}
      {isLoading ? (
        <div className="text-center py-10">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>Loading contracts...</p>
        </div>
      ) : (
        <ContractTable 
          contracts={contracts} 
          onAnalyze={handleAnalyze}
          onView={handleView}
        />
      )}

      {/* Import Contract Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Import Smart Contract
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4 py-2">
            <div className="grid w-full items-center gap-2">
              <Label htmlFor="name">Contract Name</Label>
              <Input 
                id="name"
                name="name"
                placeholder="e.g., OptimismPortal"
                value={contractDetails.name}
                onChange={handleInputChange}
                required
                className="bg-gray-700 border-gray-600"
              />
            </div>
            
            <div className="grid w-full items-center gap-2">
              <Label htmlFor="address">Contract Address</Label>
              <Input 
                id="address"
                name="address"
                placeholder="0x..."
                value={contractDetails.address}
                onChange={handleInputChange}
                required
                className="bg-gray-700 border-gray-600"
              />
            </div>
            
            <div className="grid w-full items-center gap-2">
              <Label htmlFor="network">Network</Label>
              <select 
                id="network"
                name="network"
                value={contractDetails.network}
                onChange={handleInputChange as any}
                required
                className="flex h-10 w-full rounded-md border border-gray-600 bg-gray-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value="optimism">Optimism Mainnet</option>
                <option value="optimism-goerli">Optimism Goerli</option>
                <option value="local">Local Development</option>
              </select>
            </div>
            
            <div className="grid w-full items-center gap-2">
              <Label htmlFor="source">Contract Source Code</Label>
              <Textarea 
                id="source"
                name="source"
                placeholder="// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract YourContract {
    // ...
}"
                value={contractDetails.source}
                onChange={handleInputChange}
                required
                className="min-h-32 bg-gray-700 border-gray-600"
              />
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="ghost"
                onClick={() => setOpen(false)}
                className="mr-2"
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={addContractMutation.isPending}
              >
                {addContractMutation.isPending ? "Importing..." : "Import Contract"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Contract Vulnerability View Dialog */}
      <Dialog open={viewOpen} onOpenChange={setViewOpen}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              {viewingContract?.name}
              <span className="ml-2 text-sm font-normal text-gray-400">
                Vulnerability Analysis
              </span>
            </DialogTitle>
          </DialogHeader>
          
          {viewingContract && (
            <ContractVulnerabilityView contract={viewingContract} />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
