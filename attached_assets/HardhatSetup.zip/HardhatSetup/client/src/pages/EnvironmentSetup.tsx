import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { setupHardhatEnvironment } from "@/lib/hardhatUtils";
import { useToast } from "@/hooks/use-toast";
import ConfigFileCard from "@/components/ConfigFileCard";
import TerminalOutput from "@/components/TerminalOutput";
import { defaultHardhatConfig } from "@/lib/hardhatUtils";

export default function EnvironmentSetup() {
  const [setupSteps, setSetupSteps] = useState({
    hardhat: false,
    tools: false,
    optimismSDK: false
  });
  const [terminalOutput, setTerminalOutput] = useState<string[]>([
    "$ npm init -y",
    "Initialized new project...",
    "$ mkdir contracts test scripts"
  ]);
  const [isSettingUp, setIsSettingUp] = useState(false);
  const [configCode, setConfigCode] = useState(defaultHardhatConfig);
  const { toast } = useToast();

  const setupEnvironment = async () => {
    setIsSettingUp(true);
    setTerminalOutput(prev => [...prev, "$ npm install --save-dev hardhat"]);
    
    try {
      // Simulate installation process with terminal output updates
      await new Promise(resolve => setTimeout(resolve, 1000));
      setTerminalOutput(prev => [...prev, "Installing hardhat and dependencies..."]);
      
      await new Promise(resolve => setTimeout(resolve, 1500));
      setTerminalOutput(prev => [
        ...prev, 
        "Success: Installed hardhat v2.15.0",
        "$ npm install --save-dev @nomiclabs/hardhat-ethers ethers"
      ]);
      
      await new Promise(resolve => setTimeout(resolve, 1200));
      setTerminalOutput(prev => [
        ...prev, 
        "Success: Installed @nomiclabs/hardhat-ethers",
        "Success: Installed ethers.js",
        "$ npm install --save-dev @eth-optimism/sdk"
      ]);
      
      await new Promise(resolve => setTimeout(resolve, 1500));
      setTerminalOutput(prev => [...prev, "Success: Installed @eth-optimism/sdk"]);
      
      // Call actual API endpoint
      await setupHardhatEnvironment();
      
      // Update setup status
      setSetupSteps({
        hardhat: true,
        tools: true,
        optimismSDK: true
      });
      
      toast({
        title: "Setup Complete",
        description: "Hardhat environment has been set up successfully!",
      });
    } catch (error) {
      toast({
        title: "Setup Failed",
        description: "Failed to set up the Hardhat environment. Please try again.",
        variant: "destructive",
      });
      setTerminalOutput(prev => [...prev, "Error: Failed to complete setup"]);
    } finally {
      setIsSettingUp(false);
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Hardhat + Optimism Security Testing Environment</h1>
        <p className="text-gray-400 mb-4">Configure your environment and import smart contracts for security analysis</p>
        <div className="flex flex-wrap gap-2">
          <div className="bg-gray-700 text-xs px-2 py-1 rounded-md flex items-center">
            <span className={`w-2 h-2 ${setupSteps.hardhat ? "bg-green-500" : "bg-gray-500"} rounded-full mr-1`}></span>
            Hardhat v2.15.0
          </div>
          <div className="bg-gray-700 text-xs px-2 py-1 rounded-md flex items-center">
            <span className="w-2 h-2 bg-green-500 rounded-full mr-1"></span>
            Node.js v18.16.0
          </div>
          <div className="bg-gray-700 text-xs px-2 py-1 rounded-md flex items-center">
            <span className={`w-2 h-2 ${setupSteps.optimismSDK ? "bg-green-500" : "bg-gray-500"} rounded-full mr-1`}></span>
            Optimism SDK
          </div>
        </div>
      </div>

      <div className="mb-8">
        <h2 className="text-lg font-semibold mb-4">Environment Configuration</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="bg-gray-800 border border-gray-700 rounded-lg p-4">
            <div className="flex items-center mb-3">
              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center mr-3">
                <span className="font-bold">1</span>
              </div>
              <h3 className="font-medium">Install Hardhat</h3>
            </div>
            <TerminalOutput 
              output={["$ npm install --save-dev hardhat"]}
              className="mb-3"
            />
            <span className={`inline-block px-2 py-1 text-xs rounded ${
              setupSteps.hardhat ? "bg-green-900 text-green-300" : "bg-gray-700 text-gray-300"
            }`}>
              {setupSteps.hardhat ? "Completed" : "Pending"}
            </span>
          </Card>
          <Card className="bg-gray-800 border border-gray-700 rounded-lg p-4">
            <div className="flex items-center mb-3">
              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center mr-3">
                <span className="font-bold">2</span>
              </div>
              <h3 className="font-medium">Add Testing Tools</h3>
            </div>
            <TerminalOutput 
              output={["$ npm i -D @nomiclabs/hardhat-ethers ethers"]}
              className="mb-3"
            />
            <span className={`inline-block px-2 py-1 text-xs rounded ${
              setupSteps.tools ? "bg-green-900 text-green-300" : "bg-gray-700 text-gray-300"
            }`}>
              {setupSteps.tools ? "Completed" : "Pending"}
            </span>
          </Card>
          <Card className="bg-gray-800 border border-gray-700 rounded-lg p-4">
            <div className="flex items-center mb-3">
              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center mr-3">
                <span className="font-bold">3</span>
              </div>
              <h3 className="font-medium">Install Optimism SDK</h3>
            </div>
            <TerminalOutput 
              output={["$ npm i -D @eth-optimism/sdk"]}
              className="mb-3"
            />
            <span className={`inline-block px-2 py-1 text-xs rounded ${
              setupSteps.optimismSDK ? "bg-green-900 text-green-300" : "bg-gray-700 text-gray-300"
            }`}>
              {setupSteps.optimismSDK ? "Completed" : "Pending"}
            </span>
          </Card>
        </div>
      </div>

      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Hardhat Configuration</h2>
          <Button onClick={() => toast({ title: "Configuration saved" })}>
            Save Changes
          </Button>
        </div>
        <ConfigFileCard 
          fileName="hardhat.config.js"
          code={configCode}
          onSave={setConfigCode}
        />
      </div>

      <div className="mb-8">
        <h2 className="text-lg font-semibold mb-4">Project Setup</h2>
        <Card className="bg-gray-800 border border-gray-700 rounded-lg p-4">
          <TerminalOutput 
            output={terminalOutput}
            isLoading={isSettingUp}
            className="mb-4"
          />
          <div className="flex space-x-3">
            <Button 
              onClick={setupEnvironment}
              disabled={isSettingUp || (setupSteps.hardhat && setupSteps.tools && setupSteps.optimismSDK)}
            >
              {isSettingUp ? "Setting Up..." : "Setup Environment"}
            </Button>
            <Link href="/security-tools" 
              className={`inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none ring-offset-background bg-gray-700 hover:bg-gray-600 text-white h-10 py-2 px-4 ${
                !(setupSteps.hardhat && setupSteps.tools && setupSteps.optimismSDK) ? "opacity-50 pointer-events-none" : ""
              }`}>
              Next: Security Tools
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
