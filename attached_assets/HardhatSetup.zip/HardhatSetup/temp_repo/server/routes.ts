import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContractSchema, insertSecurityToolSchema, insertTestCaseSchema, insertFindingSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { exec } from "child_process";
import { promisify } from "util";
import path from "path";
import fs from "fs/promises";

const execPromise = promisify(exec);

export async function registerRoutes(app: Express): Promise<Server> {
  // Contracts API
  app.get("/api/contracts", async (req, res) => {
    const contracts = await storage.getContracts();
    res.json(contracts);
  });

  app.get("/api/contracts/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid contract ID" });
    }

    const contract = await storage.getContract(id);
    if (!contract) {
      return res.status(404).json({ message: "Contract not found" });
    }

    res.json(contract);
  });

  app.post("/api/contracts", async (req, res) => {
    try {
      const contractData = insertContractSchema.parse(req.body);
      const contract = await storage.createContract(contractData);
      res.status(201).json(contract);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to create contract" });
    }
  });

  app.patch("/api/contracts/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid contract ID" });
    }

    try {
      const updatedContract = await storage.updateContract(id, req.body);
      if (!updatedContract) {
        return res.status(404).json({ message: "Contract not found" });
      }
      res.json(updatedContract);
    } catch (error) {
      res.status(500).json({ message: "Failed to update contract" });
    }
  });

  app.delete("/api/contracts/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid contract ID" });
    }

    const success = await storage.deleteContract(id);
    if (!success) {
      return res.status(404).json({ message: "Contract not found" });
    }
    
    res.status(204).end();
  });

  // Security Tools API
  app.get("/api/security-tools", async (req, res) => {
    const tools = await storage.getSecurityTools();
    res.json(tools);
  });

  app.get("/api/security-tools/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid tool ID" });
    }

    const tool = await storage.getSecurityTool(id);
    if (!tool) {
      return res.status(404).json({ message: "Security tool not found" });
    }

    res.json(tool);
  });

  app.post("/api/security-tools", async (req, res) => {
    try {
      const toolData = insertSecurityToolSchema.parse(req.body);
      const tool = await storage.createSecurityTool(toolData);
      res.status(201).json(tool);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to create security tool" });
    }
  });

  app.patch("/api/security-tools/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid tool ID" });
    }

    try {
      const updatedTool = await storage.updateSecurityTool(id, req.body);
      if (!updatedTool) {
        return res.status(404).json({ message: "Security tool not found" });
      }
      res.json(updatedTool);
    } catch (error) {
      res.status(500).json({ message: "Failed to update security tool" });
    }
  });

  // Test Cases API
  app.get("/api/test-cases", async (req, res) => {
    const contractId = req.query.contractId ? parseInt(req.query.contractId as string) : undefined;
    
    if (contractId) {
      if (isNaN(contractId)) {
        return res.status(400).json({ message: "Invalid contract ID" });
      }
      const testCases = await storage.getTestCasesByContract(contractId);
      return res.json(testCases);
    }
    
    const testCases = await storage.getAllTestCases();
    res.json(testCases);
  });

  app.get("/api/test-cases/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid test case ID" });
    }

    const testCase = await storage.getTestCase(id);
    if (!testCase) {
      return res.status(404).json({ message: "Test case not found" });
    }

    res.json(testCase);
  });

  app.post("/api/test-cases", async (req, res) => {
    try {
      const testCaseData = insertTestCaseSchema.parse(req.body);
      const testCase = await storage.createTestCase(testCaseData);
      res.status(201).json(testCase);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to create test case" });
    }
  });

  app.patch("/api/test-cases/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid test case ID" });
    }

    try {
      const updatedTestCase = await storage.updateTestCase(id, req.body);
      if (!updatedTestCase) {
        return res.status(404).json({ message: "Test case not found" });
      }
      res.json(updatedTestCase);
    } catch (error) {
      res.status(500).json({ message: "Failed to update test case" });
    }
  });

  app.delete("/api/test-cases/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid test case ID" });
    }

    const success = await storage.deleteTestCase(id);
    if (!success) {
      return res.status(404).json({ message: "Test case not found" });
    }
    
    res.status(204).end();
  });

  // Findings API
  app.get("/api/findings", async (req, res) => {
    const contractId = req.query.contractId ? parseInt(req.query.contractId as string) : undefined;
    
    if (contractId) {
      if (isNaN(contractId)) {
        return res.status(400).json({ message: "Invalid contract ID" });
      }
      const findings = await storage.getFindingsByContract(contractId);
      return res.json(findings);
    }
    
    const findings = await storage.getAllFindings();
    res.json(findings);
  });

  app.post("/api/findings", async (req, res) => {
    try {
      const findingData = insertFindingSchema.parse(req.body);
      const finding = await storage.createFinding(findingData);
      res.status(201).json(finding);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to create finding" });
    }
  });

  app.delete("/api/findings/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid finding ID" });
    }

    const success = await storage.deleteFinding(id);
    if (!success) {
      return res.status(404).json({ message: "Finding not found" });
    }
    
    res.status(204).end();
  });

  // Hardhat API - Installation simulation
  app.post("/api/hardhat/setup", async (req, res) => {
    try {
      // Simulate hardhat installation
      await new Promise(resolve => setTimeout(resolve, 1500));
      res.json({ success: true, message: "Hardhat environment setup successfully" });
    } catch (error) {
      res.status(500).json({ success: false, message: "Failed to setup Hardhat environment" });
    }
  });

  // Security tools installation simulation
  app.post("/api/security-tools/:id/install", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid tool ID" });
    }

    try {
      const tool = await storage.getSecurityTool(id);
      if (!tool) {
        return res.status(404).json({ message: "Security tool not found" });
      }

      // Simulate installation process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mark tool as installed
      const updatedTool = await storage.updateSecurityTool(id, { installed: true });
      res.json({ success: true, tool: updatedTool });
    } catch (error) {
      res.status(500).json({ success: false, message: "Failed to install security tool" });
    }
  });

  // Run tests simulation
  app.post("/api/test-cases/:id/run", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid test case ID" });
    }

    try {
      const testCase = await storage.getTestCase(id);
      if (!testCase) {
        return res.status(404).json({ message: "Test case not found" });
      }

      // Simulate test run
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Update test case with results
      const passed = Math.random() > 0.3; // 70% chance of success for demo
      const updatedTestCase = await storage.updateTestCase(id, { 
        lastRun: new Date(),
        passed
      });

      // If test failed, create a finding
      if (!passed) {
        const finding = await storage.createFinding({
          contractId: testCase.contractId,
          testCaseId: id,
          toolId: null,
          severity: "medium",
          title: `Issue detected in ${testCase.name}`,
          description: "Potential vulnerability detected during test execution",
          recommendation: "Review the test output and update the contract code",
          code: testCase.code
        });
      }

      res.json({ 
        success: true, 
        testCase: updatedTestCase,
        result: {
          passed,
          output: passed 
            ? "Test completed successfully. No vulnerabilities detected."
            : "Test failed. Potential vulnerability detected."
        }
      });
    } catch (error) {
      res.status(500).json({ success: false, message: "Failed to run test case" });
    }
  });

  // Generate report
  app.post("/api/reports/generate", async (req, res) => {
    try {
      const findings = await storage.getAllFindings();
      const contracts = await storage.getContracts();

      const criticalCount = findings.filter(f => f.severity === "critical").length;
      const highCount = findings.filter(f => f.severity === "high").length;
      const mediumCount = findings.filter(f => f.severity === "medium").length;
      const lowCount = findings.filter(f => f.severity === "low").length;

      res.json({
        generated: new Date(),
        summary: {
          contractsAnalyzed: contracts.length,
          findings: findings.length,
          severityCounts: {
            critical: criticalCount,
            high: highCount,
            medium: mediumCount,
            low: lowCount
          }
        },
        findings: findings
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate report" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
