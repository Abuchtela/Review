import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ReportSummary from "@/components/ReportSummary";
import { Card } from "@/components/ui/card";

export default function Reports() {
  const [generatingReport, setGeneratingReport] = useState(false);
  const { toast } = useToast();

  // Fetch findings
  const { 
    data: findings = [],
    isLoading,
    refetch: refetchFindings
  } = useQuery({
    queryKey: ['/api/findings'],
    staleTime: 60000 // 1 minute
  });

  // Generate report mutation
  const generateReportMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/reports/generate", null);
      return res.json();
    },
    onMutate: () => {
      setGeneratingReport(true);
    },
    onSuccess: (data) => {
      setGeneratingReport(false);
      refetchFindings();
      toast({
        title: "Report Generated",
        description: "Security report has been generated successfully.",
      });
    },
    onError: () => {
      setGeneratingReport(false);
      toast({
        title: "Report Generation Failed",
        description: "Failed to generate the security report. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Count findings by severity
  const criticalCount = findings.filter(f => f.severity === "critical").length;
  const highCount = findings.filter(f => f.severity === "high").length;
  const mediumCount = findings.filter(f => f.severity === "medium").length;
  const lowCount = findings.filter(f => f.severity === "low").length;

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Security Report</h1>
        <Button 
          onClick={() => generateReportMutation.mutate()}
          disabled={generatingReport}
        >
          {generatingReport ? "Generating..." : "Generate Full Report"}
        </Button>
      </div>

      {isLoading ? (
        <div className="text-center py-10">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>Loading security findings...</p>
        </div>
      ) : findings.length === 0 ? (
        <Card className="bg-gray-800 border-gray-700 p-8 text-center">
          <h3 className="text-xl font-medium mb-2">No Security Findings Yet</h3>
          <p className="text-gray-400 mb-6">
            Run security tests on your contracts to identify vulnerabilities and generate a comprehensive security report.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">
            <div className="bg-gray-700 rounded-lg p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="text-sm font-medium text-gray-300">Critical Issues</h3>
                  <p className="text-2xl font-bold text-green-500">0</p>
                </div>
                <div className="p-2 bg-green-900 bg-opacity-20 rounded-md">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <p className="text-xs text-gray-400">No critical security vulnerabilities found</p>
            </div>
            <div className="bg-gray-700 rounded-lg p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="text-sm font-medium text-gray-300">Medium Issues</h3>
                  <p className="text-2xl font-bold text-green-500">0</p>
                </div>
                <div className="p-2 bg-green-900 bg-opacity-20 rounded-md">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <p className="text-xs text-gray-400">No medium risk issues found</p>
            </div>
            <div className="bg-gray-700 rounded-lg p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="text-sm font-medium text-gray-300">Low Issues</h3>
                  <p className="text-2xl font-bold text-green-500">0</p>
                </div>
                <div className="p-2 bg-green-900 bg-opacity-20 rounded-md">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <p className="text-xs text-gray-400">No low severity issues found</p>
            </div>
          </div>
          <Button 
            onClick={() => generateReportMutation.mutate()}
            disabled={generatingReport}
          >
            Run Security Analysis
          </Button>
        </Card>
      ) : (
        <ReportSummary
          criticalCount={criticalCount}
          highCount={highCount}
          mediumCount={mediumCount}
          lowCount={lowCount}
          findings={findings}
        />
      )}
    </div>
  );
}
