import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import TestCaseCard from "@/components/TestCaseCard";
import { TestCase } from "@shared/schema";
import { defaultReentrancyTest, defaultAccessControlTest } from "@/lib/hardhatUtils";

export default function TestCases() {
  const [open, setOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [testCaseDetails, setTestCaseDetails] = useState({
    name: "",
    description: "",
    contractId: "",
    testType: "reentrancy",
    code: defaultReentrancyTest
  });
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch test cases
  const { data: testCases = [], isLoading: isLoadingTestCases } = useQuery({
    queryKey: ['/api/test-cases'],
    staleTime: 60000 // 1 minute
  });

  // Fetch contracts (for dropdown)
  const { data: contracts = [], isLoading: isLoadingContracts } = useQuery({
    queryKey: ['/api/contracts'],
    staleTime: 60000 // 1 minute
  });

  // Add test case mutation
  const addTestCaseMutation = useMutation({
    mutationFn: async (testCaseData: any) => {
      const res = await apiRequest("POST", "/api/test-cases", testCaseData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/test-cases'] });
      setOpen(false);
      resetForm();
      toast({
        title: "Test Case Created",
        description: "The test case has been successfully created.",
      });
    },
    onError: () => {
      toast({
        title: "Creation Failed",
        description: "Failed to create the test case. Please check the details and try again.",
        variant: "destructive",
      });
    }
  });

  // Update test case mutation
  const updateTestCaseMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: any }) => {
      const res = await apiRequest("PATCH", `/api/test-cases/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/test-cases'] });
      setOpen(false);
      setIsEditing(false);
      setEditingId(null);
      resetForm();
      toast({
        title: "Test Case Updated",
        description: "The test case has been successfully updated.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update the test case. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const formData = {
      ...testCaseDetails,
      contractId: parseInt(testCaseDetails.contractId)
    };
    
    if (isEditing && editingId) {
      updateTestCaseMutation.mutate({ id: editingId, data: formData });
    } else {
      addTestCaseMutation.mutate(formData);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setTestCaseDetails(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setTestCaseDetails(prev => ({ ...prev, [name]: value }));
    
    // Update code template based on selected test type
    if (name === "testType") {
      if (value === "reentrancy") {
        setTestCaseDetails(prev => ({ ...prev, code: defaultReentrancyTest }));
      } else if (value === "access-control") {
        setTestCaseDetails(prev => ({ ...prev, code: defaultAccessControlTest }));
      }
    }
  };

  const handleEditTestCase = (testCase: TestCase) => {
    setTestCaseDetails({
      name: testCase.name,
      description: testCase.description || "",
      contractId: testCase.contractId.toString(),
      testType: testCase.testType,
      code: testCase.code
    });
    setIsEditing(true);
    setEditingId(testCase.id);
    setOpen(true);
  };

  const resetForm = () => {
    setTestCaseDetails({
      name: "",
      description: "",
      contractId: "",
      testType: "reentrancy",
      code: defaultReentrancyTest
    });
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Security Test Cases</h1>
        <Button onClick={() => {
          resetForm();
          setIsEditing(false);
          setEditingId(null);
          setOpen(true);
        }}>
          Create New Test
        </Button>
      </div>

      {isLoadingTestCases ? (
        <div className="text-center py-10">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>Loading test cases...</p>
        </div>
      ) : testCases.length === 0 ? (
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-8 text-center">
          <h3 className="text-xl font-medium mb-2">No Test Cases Yet</h3>
          <p className="text-gray-400 mb-4">
            Create test cases to check your contracts for common vulnerabilities like reentrancy attacks, access control issues, and more.
          </p>
          <Button onClick={() => setOpen(true)}>
            Create Your First Test
          </Button>
        </div>
      ) : (
        testCases.map(testCase => (
          <TestCaseCard
            key={testCase.id}
            testCase={testCase}
            onEdit={handleEditTestCase}
          />
        ))
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-4xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold">
              {isEditing ? "Edit Test Case" : "Create New Test Case"}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4 py-2">
            <div className="grid w-full items-center gap-2">
              <Label htmlFor="name">Test Name</Label>
              <Input 
                id="name"
                name="name"
                placeholder="e.g., Reentrancy Test for OptimismPortal"
                value={testCaseDetails.name}
                onChange={handleInputChange}
                required
                className="bg-gray-700 border-gray-600"
              />
            </div>
            
            <div className="grid w-full items-center gap-2">
              <Label htmlFor="description">Description</Label>
              <Input 
                id="description"
                name="description"
                placeholder="Brief description of what this test checks for"
                value={testCaseDetails.description}
                onChange={handleInputChange}
                className="bg-gray-700 border-gray-600"
              />
            </div>
            
            <div className="grid w-full items-center gap-2">
              <Label htmlFor="contractId">Target Contract</Label>
              <Select 
                value={testCaseDetails.contractId} 
                onValueChange={(value) => handleSelectChange("contractId", value)}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600">
                  <SelectValue placeholder="Select a contract" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  {contracts.map(contract => (
                    <SelectItem key={contract.id} value={contract.id.toString()}>
                      {contract.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid w-full items-center gap-2">
              <Label htmlFor="testType">Test Type</Label>
              <Select 
                value={testCaseDetails.testType} 
                onValueChange={(value) => handleSelectChange("testType", value)}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="reentrancy">Reentrancy</SelectItem>
                  <SelectItem value="access-control">Access Control</SelectItem>
                  <SelectItem value="overflow">Integer Overflow/Underflow</SelectItem>
                  <SelectItem value="frontrunning">Front-Running</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid w-full items-center gap-2">
              <Label htmlFor="code">Test Code</Label>
              <Textarea 
                id="code"
                name="code"
                value={testCaseDetails.code}
                onChange={handleInputChange}
                required
                className="min-h-64 font-mono text-sm bg-gray-700 border-gray-600"
              />
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="ghost" 
                onClick={() => {
                  setOpen(false);
                  if (isEditing) {
                    setIsEditing(false);
                    setEditingId(null);
                    resetForm();
                  }
                }}
                className="mr-2"
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={addTestCaseMutation.isPending || updateTestCaseMutation.isPending}
              >
                {isEditing 
                  ? (updateTestCaseMutation.isPending ? "Updating..." : "Update Test Case") 
                  : (addTestCaseMutation.isPending ? "Creating..." : "Create Test Case")}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <div className="flex justify-end space-x-4 mt-8">
        <Link href="/security-tools">
          <a className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ring-offset-background border border-input hover:bg-accent hover:text-accent-foreground h-10 py-2 px-4 bg-gray-700 hover:bg-gray-600 text-white">
            Back to Tools
          </a>
        </Link>
        <Link href="/reports">
          <a className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ring-offset-background h-10 py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white">
            Next: Reports
          </a>
        </Link>
      </div>
    </div>
  );
}
