import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import SecurityToolCard from "@/components/SecurityToolCard";
import { Link } from "wouter";

export default function SecurityTools() {
  // Fetch security tools
  const { data: securityTools = [], isLoading } = useQuery({
    queryKey: ['/api/security-tools'],
    staleTime: 60000 // 1 minute
  });

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Security Analysis Tools</h1>
        <p className="text-gray-400 mb-4">
          Install and configure security analysis tools to scan your Optimism smart contracts for vulnerabilities.
        </p>
      </div>

      {isLoading ? (
        <div className="text-center py-10">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>Loading security tools...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {securityTools.map(tool => (
            <SecurityToolCard key={tool.id} tool={tool} />
          ))}
        </div>
      )}

      <div className="flex justify-end space-x-4 mt-8">
        <Link href="/environment-setup">
          <a className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ring-offset-background border border-input hover:bg-accent hover:text-accent-foreground h-10 py-2 px-4 bg-gray-700 hover:bg-gray-600 text-white">
            Back to Setup
          </a>
        </Link>
        <Link href="/test-cases">
          <a className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ring-offset-background h-10 py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white">
            Next: Test Cases
          </a>
        </Link>
      </div>
    </div>
  );
}
