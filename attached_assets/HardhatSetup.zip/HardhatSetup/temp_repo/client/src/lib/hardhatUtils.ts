import { apiRequest } from "./queryClient";

export async function setupHardhatEnvironment() {
  try {
    const response = await apiRequest("POST", "/api/hardhat/setup", null);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Failed to setup Hardhat environment:", error);
    throw error;
  }
}

export const defaultHardhatConfig = `require("@nomiclabs/hardhat-ethers");
const { optimismSDK } = require("@eth-optimism/sdk");

module.exports = {
  solidity: {
    version: "0.8.17",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200
      }
    }
  },
  networks: {
    hardhat: {
      chainId: 10, // Optimism mainnet chainId
    },
    optimism: {
      url: "https://mainnet.optimism.io",
      accounts: [\${process.env.PRIVATE_KEY}]
    },
    optimismGoerli: {
      url: "https://goerli.optimism.io",
      accounts: [\${process.env.PRIVATE_KEY}]
    }
  },
  paths: {
    sources: "./contracts",
    tests: "./test",
    artifacts: "./artifacts"
  },
  mocha: {
    timeout: 40000
  }
};`;

export const defaultReentrancyTest = `const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Reentrancy Attack Test", function() {
  let attackerContract;
  let vulnerableContract;
  let owner;
  let attacker;

  beforeEach(async function() {
    [owner, attacker] = await ethers.getSigners();
    
    const VulnerableContract = await ethers.getContractFactory("L1CrossDomainMessenger");
    vulnerableContract = await VulnerableContract.deploy();
    await vulnerableContract.deployed();
    
    const AttackerContract = await ethers.getContractFactory("ReentrancyAttacker");
    attackerContract = await AttackerContract.deploy(vulnerableContract.address);
    await attackerContract.deployed();
  });

  it("should not allow reentrancy attacks", async function() {
    // Fund the vulnerable contract
    await owner.sendTransaction({
      to: vulnerableContract.address,
      value: ethers.utils.parseEther("1.0")
    });
    
    // Check balance before attack
    const initialBalance = await ethers.provider.getBalance(attackerContract.address);
    
    // Attempt the attack
    await expect(
      attackerContract.connect(attacker).attack({ value: ethers.utils.parseEther("0.1") })
    ).to.be.reverted;
    
    // Check balance after attack
    const finalBalance = await ethers.provider.getBalance(attackerContract.address);
    
    // Ensure no ether was stolen
    expect(finalBalance).to.equal(initialBalance);
  });
});`;

export const defaultAccessControlTest = `const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Access Control Test", function() {
  let contract;
  let owner;
  let user;

  beforeEach(async function() {
    [owner, user] = await ethers.getSigners();
    
    const Contract = await ethers.getContractFactory("OptimismPortal");
    contract = await Contract.deploy();
    await contract.deployed();
  });

  it("should restrict administrative functions to owner", async function() {
    // Attempt to call an admin function as non-owner
    await expect(
      contract.connect(user).pause()
    ).to.be.reverted;
    
    // Owner should be able to call the function
    await contract.connect(owner).pause();
    
    // Verify the contract state reflects the change
    expect(await contract.paused()).to.equal(true);
  });
});`;

export const sampleContracts = [
  {
    name: "OptimismPortal",
    address: "0x5a5e5d3a365b2e1b8e57f85db4a7eb5cae4e42a",
    source: `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract OptimismPortal {
    bool private paused;
    address private owner;

    constructor() {
        owner = msg.sender;
        paused = false;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "Not authorized");
        _;
    }

    function isPaused() external view returns (bool) {
        return paused;
    }

    function pause() external onlyOwner {
        paused = true;
    }

    function unpause() external onlyOwner {
        paused = false;
    }

    function depositTransaction() external payable {
        require(!paused, "Portal is paused");
        // Implementation would go here
    }
}`,
    network: "optimism",
    verified: true
  },
  {
    name: "L1CrossDomainMessenger",
    address: "0x2db77c9b93cf84b31198f68b40fc578577a7a12",
    source: `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract L1CrossDomainMessenger {
    mapping(bytes32 => bool) public sentMessages;
    mapping(bytes32 => bool) public receivedMessages;
    address private owner;

    constructor() {
        owner = msg.sender;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "Not authorized");
        _;
    }

    function sendMessage(
        address _target,
        bytes calldata _message,
        uint32 _gasLimit
    ) external payable {
        bytes32 messageHash = keccak256(abi.encode(_target, _message, _gasLimit));
        sentMessages[messageHash] = true;
        // Implementation would go here
    }

    function receiveMessage(
        address _sender,
        address _target,
        bytes calldata _message,
        uint32 _gasLimit
    ) external {
        bytes32 messageHash = keccak256(abi.encode(_sender, _target, _message, _gasLimit));
        require(!receivedMessages[messageHash], "Message already received");
        receivedMessages[messageHash] = true;
        // Implementation would go here
    }
}`,
    network: "optimism",
    verified: true
  }
];
