import { Link, useLocation } from "wouter";
import { 
  Settings, FileDown, Package, 
  Beaker, Search, RotateCcw, 
  Zap, Clock, Shield, BarChart4, 
  AlertTriangle, FileText
} from "lucide-react";

type SidebarProps = {
  isOpen: boolean;
};

type NavItemProps = {
  href: string;
  icon: React.ReactNode;
  label: string;
  isActive?: boolean;
};

function NavItem({ href, icon, label, isActive }: NavItemProps) {
  return (
    <li>
      <Link href={href} className={`flex items-center px-3 py-2 text-sm rounded-md ${
        isActive ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700'
      }`}>
        <span className="mr-3 h-4 w-4">{icon}</span>
        {label}
      </Link>
    </li>
  );
}

export default function Sidebar({ isOpen }: SidebarProps) {
  const [location] = useLocation();

  if (!isOpen) {
    return null;
  }

  return (
    <aside className="w-64 bg-gray-800 border-r border-gray-700 flex-shrink-0 hidden md:block">
      <nav className="p-4 h-full overflow-y-auto">
        <div className="mb-6">
          <h2 className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
            Project Setup
          </h2>
          <ul className="space-y-1">
            <NavItem 
              href="/environment-setup" 
              icon={<Settings />} 
              label="Environment Setup" 
              isActive={location === "/environment-setup"}
            />
            <NavItem 
              href="/contract-import" 
              icon={<FileDown />} 
              label="Contract Import" 
              isActive={location === "/contract-import"}
            />
            <NavItem 
              href="#" 
              icon={<Package />} 
              label="Dependencies" 
            />
          </ul>
        </div>
        
        <div className="mb-6">
          <h2 className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
            Testing Tools
          </h2>
          <ul className="space-y-1">
            <NavItem 
              href="/security-tools" 
              icon={<Beaker />} 
              label="Security Tools"
              isActive={location === "/security-tools"}
            />
            <NavItem 
              href="#" 
              icon={<Search />} 
              label="Mythril" 
            />
            <NavItem 
              href="#" 
              icon={<Zap />} 
              label="Echidna" 
            />
            <NavItem 
              href="/test-cases" 
              icon={<FileText />} 
              label="Custom Tests"
              isActive={location === "/test-cases"}
            />
          </ul>
        </div>
        
        <div className="mb-6">
          <h2 className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
            Vulnerability Types
          </h2>
          <ul className="space-y-1">
            <NavItem 
              href="#" 
              icon={<RotateCcw />} 
              label="Reentrancy" 
            />
            <NavItem 
              href="#" 
              icon={<Zap />} 
              label="Overflow/Underflow" 
            />
            <NavItem 
              href="#" 
              icon={<Clock />} 
              label="Front-Running" 
            />
            <NavItem 
              href="#" 
              icon={<Shield />} 
              label="Access Control" 
            />
          </ul>
        </div>
        
        <div>
          <h2 className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
            Reports
          </h2>
          <ul className="space-y-1">
            <NavItem 
              href="/reports" 
              icon={<BarChart4 />} 
              label="Security Summary"
              isActive={location === "/reports"}
            />
            <NavItem 
              href="#" 
              icon={<AlertTriangle />} 
              label="Vulnerability Details" 
            />
            <NavItem 
              href="#" 
              icon={<BarChart4 />} 
              label="Gas Analysis" 
            />
          </ul>
        </div>
      </nav>
    </aside>
  );
}
