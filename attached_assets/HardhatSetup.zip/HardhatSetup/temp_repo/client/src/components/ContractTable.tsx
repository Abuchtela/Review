import { useState } from "react";
import { Contract } from "@shared/schema";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

type ContractTableProps = {
  contracts: Contract[];
  onAnalyze: (contract: Contract) => void;
  onView: (contract: Contract) => void;
};

export default function ContractTable({ contracts, onAnalyze, onView }: ContractTableProps) {
  const [analyzingIds, setAnalyzingIds] = useState<number[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const analyzeContractMutation = useMutation({
    mutationFn: async (contractId: number) => {
      // Simulating contract analysis process
      await new Promise(resolve => setTimeout(resolve, 3000));
      return { success: true };
    },
    onMutate: (contractId) => {
      setAnalyzingIds(prev => [...prev, contractId]);
    },
    onSuccess: (_, contractId) => {
      setAnalyzingIds(prev => prev.filter(id => id !== contractId));
      
      // Update contract with security score
      const updateContract = async () => {
        const randomScore = Math.floor(Math.random() * 30) + 65; // 65-95
        await apiRequest("PATCH", `/api/contracts/${contractId}`, { 
          securityScore: randomScore
        });
        queryClient.invalidateQueries({ queryKey: ['/api/contracts'] });
      };
      
      updateContract();
      
      toast({
        title: "Analysis Complete",
        description: "Contract security analysis has been completed successfully."
      });
    },
    onError: (_, contractId) => {
      setAnalyzingIds(prev => prev.filter(id => id !== contractId));
      toast({
        title: "Analysis Failed",
        description: "Failed to analyze contract security. Please try again.",
        variant: "destructive"
      });
    }
  });

  return (
    <div className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="bg-gray-700">
            <TableRow>
              <TableHead className="text-gray-300">Contract Name</TableHead>
              <TableHead className="text-gray-300">Address</TableHead>
              <TableHead className="text-gray-300">Status</TableHead>
              <TableHead className="text-gray-300">Security Score</TableHead>
              <TableHead className="text-gray-300">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody className="divide-y divide-gray-700 bg-gray-800">
            {contracts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-gray-400">
                  No contracts imported yet. Use the "Import New Contract" button to add contracts.
                </TableCell>
              </TableRow>
            ) : (
              contracts.map((contract) => (
                <TableRow key={contract.id}>
                  <TableCell className="font-medium">
                    {contract.name}
                  </TableCell>
                  <TableCell className="text-gray-300">
                    {/* Truncate long addresses */}
                    {contract.address.substring(0, 6)}...{contract.address.substring(contract.address.length - 4)}
                  </TableCell>
                  <TableCell>
                    {contract.verified ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-900 text-green-300">
                        Verified
                      </span>
                    ) : analyzingIds.includes(contract.id) ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-900 text-blue-300">
                        Analyzing
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-900 text-yellow-300">
                        Unverified
                      </span>
                    )}
                  </TableCell>
                  <TableCell>
                    {contract.securityScore ? (
                      <div className="flex items-center">
                        <div className="w-16 bg-gray-700 rounded-full h-2 mr-2">
                          <div 
                            className={`h-2 rounded-full ${
                              contract.securityScore >= 80 ? "bg-green-500" : 
                              contract.securityScore >= 60 ? "bg-yellow-500" : "bg-red-500"
                            }`} 
                            style={{ width: `${contract.securityScore}%` }}
                          />
                        </div>
                        <span className="text-sm text-gray-300">{contract.securityScore}%</span>
                      </div>
                    ) : analyzingIds.includes(contract.id) ? (
                      <div className="flex items-center">
                        <div className="w-16 bg-gray-700 rounded-full h-2 mr-2">
                          <div className="bg-blue-500 h-2 rounded-full animate-pulse" style={{ width: "40%" }} />
                        </div>
                        <span className="text-sm text-gray-300">In progress</span>
                      </div>
                    ) : (
                      <span className="text-sm text-gray-300">Not analyzed</span>
                    )}
                  </TableCell>
                  <TableCell className="text-sm text-gray-300">
                    {analyzingIds.includes(contract.id) ? (
                      <Button variant="ghost" className="text-gray-500 cursor-not-allowed mr-3" disabled>
                        Analyze
                      </Button>
                    ) : (
                      <Button 
                        variant="ghost" 
                        className="text-blue-500 hover:text-blue-400 mr-3" 
                        onClick={() => {
                          onAnalyze(contract);
                          analyzeContractMutation.mutate(contract.id);
                        }}
                      >
                        Analyze
                      </Button>
                    )}
                    <Button 
                      variant="ghost" 
                      className="text-gray-400 hover:text-gray-300"
                      onClick={() => onView(contract)}
                    >
                      View
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
