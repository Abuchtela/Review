import { Card } from "@/components/ui/card";
import { AlertTriangle, AlertCircle, Info } from "lucide-react";
import { Finding } from "@shared/schema";

type ReportSummaryProps = {
  criticalCount: number;
  highCount: number;
  mediumCount: number;
  lowCount: number;
  findings: Finding[];
};

export default function ReportSummary({ 
  criticalCount,
  highCount, 
  mediumCount, 
  lowCount,
  findings
}: ReportSummaryProps) {
  return (
    <div className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden">
      <div className="p-5">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">
          <div className="bg-gray-700 rounded-lg p-4">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="text-sm font-medium text-gray-300">Critical Issues</h3>
                <p className="text-2xl font-bold text-red-500">{criticalCount}</p>
              </div>
              <div className="p-2 bg-red-900 bg-opacity-20 rounded-md">
                <AlertCircle className="h-6 w-6 text-red-500" />
              </div>
            </div>
            <p className="text-xs text-gray-400">
              {criticalCount === 0 
                ? "No critical security vulnerabilities found" 
                : `${criticalCount} critical security issues need immediate attention`}
            </p>
          </div>
          <div className="bg-gray-700 rounded-lg p-4">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="text-sm font-medium text-gray-300">Medium Issues</h3>
                <p className="text-2xl font-bold text-yellow-500">{mediumCount}</p>
              </div>
              <div className="p-2 bg-yellow-900 bg-opacity-20 rounded-md">
                <AlertTriangle className="h-6 w-6 text-yellow-500" />
              </div>
            </div>
            <p className="text-xs text-gray-400">
              {mediumCount === 0 
                ? "No medium risk issues found" 
                : `${mediumCount} medium risk issues requiring attention`}
            </p>
          </div>
          <div className="bg-gray-700 rounded-lg p-4">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="text-sm font-medium text-gray-300">Low Issues</h3>
                <p className="text-2xl font-bold text-blue-400">{lowCount}</p>
              </div>
              <div className="p-2 bg-blue-900 bg-opacity-20 rounded-md">
                <Info className="h-6 w-6 text-blue-400" />
              </div>
            </div>
            <p className="text-xs text-gray-400">
              {lowCount === 0 
                ? "No low severity issues found" 
                : "Minor issues with low impact on security"}
            </p>
          </div>
        </div>

        {findings.length > 0 && (
          <div className="mb-6">
            <h3 className="text-sm font-medium text-gray-300 mb-3">Summary of Findings</h3>
            <div className="bg-gray-700 rounded-lg p-4 text-sm">
              <p className="mb-2 text-gray-300">Our security audit revealed the following issues:</p>
              <ul className="list-disc pl-5 space-y-1 text-gray-300">
                {findings.map((finding) => (
                  <li key={finding.id}>
                    {finding.title} ({finding.severity})
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {findings.length > 0 && (
          <div>
            <h3 className="text-sm font-medium text-gray-300 mb-3">Recommendations</h3>
            {findings.map((finding) => (
              <div key={finding.id} className="bg-gray-700 rounded-lg p-4 mb-3 text-sm">
                <div className="flex items-center mb-2">
                  {finding.severity === "critical" && <AlertCircle className="h-5 w-5 mr-2 text-red-500" />}
                  {finding.severity === "medium" && <AlertTriangle className="h-5 w-5 mr-2 text-yellow-500" />}
                  {finding.severity === "low" && <Info className="h-5 w-5 mr-2 text-blue-400" />}
                  <h4 className="font-medium text-gray-300">{finding.title}</h4>
                </div>
                <p className="text-gray-400 mb-2">{finding.description}</p>
                {finding.recommendation && (
                  <div className="bg-gray-800 rounded p-2 font-mono text-xs">
                    <p className="text-yellow-400">// Recommendation</p>
                    <p className="text-green-400">{finding.recommendation}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
