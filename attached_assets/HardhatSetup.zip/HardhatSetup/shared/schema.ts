import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User accounts
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Smart contracts to be analyzed
export const contracts = pgTable("contracts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  source: text("source").notNull(),
  network: text("network").notNull(),
  verified: boolean("verified").default(false),
  securityScore: integer("security_score"),
  dateAdded: timestamp("date_added").defaultNow(),
});

export const insertContractSchema = createInsertSchema(contracts).omit({
  id: true,
  dateAdded: true,
});

// Security tool configurations
export const securityTools = pgTable("security_tools", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  version: text("version"),
  installed: boolean("installed").default(false),
  configOptions: json("config_options").$type<Record<string, any>>(),
});

export const insertSecurityToolSchema = createInsertSchema(securityTools).omit({
  id: true,
});

// Security test cases
export const testCases = pgTable("test_cases", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  contractId: integer("contract_id").notNull(),
  testType: text("test_type").notNull(),
  code: text("code").notNull(),
  lastRun: timestamp("last_run"),
  passed: boolean("passed"),
});

export const insertTestCaseSchema = createInsertSchema(testCases).omit({
  id: true,
  lastRun: true,
  passed: true,
});

// Security findings
export const findings = pgTable("findings", {
  id: serial("id").primaryKey(),
  contractId: integer("contract_id").notNull(),
  testCaseId: integer("test_case_id"),
  toolId: integer("tool_id"),
  severity: text("severity").notNull(), // critical, high, medium, low, info
  title: text("title").notNull(),
  description: text("description").notNull(),
  recommendation: text("recommendation"),
  code: text("code"),
  dateFound: timestamp("date_found").defaultNow(),
});

export const insertFindingSchema = createInsertSchema(findings).omit({
  id: true,
  dateFound: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Contract = typeof contracts.$inferSelect;
export type InsertContract = z.infer<typeof insertContractSchema>;

export type SecurityTool = typeof securityTools.$inferSelect;
export type InsertSecurityTool = z.infer<typeof insertSecurityToolSchema>;

export type TestCase = typeof testCases.$inferSelect;
export type InsertTestCase = z.infer<typeof insertTestCaseSchema>;

export type Finding = typeof findings.$inferSelect;
export type InsertFinding = z.infer<typeof insertFindingSchema>;
