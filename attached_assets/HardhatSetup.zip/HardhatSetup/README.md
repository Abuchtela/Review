# Optimism Security Analyzer

A comprehensive security testing framework for analyzing smart contract vulnerabilities, focusing on Optimism's blockchain infrastructure.

## Key Features

- **Smart contract vulnerability scanning**: Identify common and Optimism-specific vulnerabilities in smart contracts with our "Vulnerability Whispers" contextual tooltips
- **Multi-contract import and analysis**: Import and analyze multiple contracts, including their interactions
- **Automated security assessment tools**: Leverage built-in security scanning tools optimized for Optimism's architecture
- **Optimism-specific contract support**: Specialized analysis for L1/L2 bridges, cross-domain messengers, and other Optimism components

## Getting Started

1. Clone this repository
2. Install dependencies: `npm install`
3. Start the development server: `npm run dev`

## Usage

### Importing Contracts

1. Navigate to the "Optimism Smart Contracts" page
2. Click "Import New Contract" or use "Import Samples" to load example contracts
3. Fill in contract details or paste source code
4. Submit to add the contract to your workspace

### Analyzing Vulnerabilities

1. Click "View" or "Analyze" on a contract card
2. The "Vulnerability Whispers" feature will:
   - Highlight potentially vulnerable code sections
   - Show tooltips with detailed information when hovering over highlighted areas
   - Display a summary of detected issues with recommendations

### Creating Test Cases

1. Navigate to the "Security Test Cases" section
2. Create custom tests for specific vulnerability patterns
3. Link tests to imported contracts
4. Run tests to verify security properties

## Project Structure

- `/client` - Frontend React application
- `/server` - Backend Express server
- `/shared` - Shared types and utilities
- `/contracts` - Sample contract files and test fixtures

## Technologies

- React with TypeScript
- Node.js backend
- Hardhat for Ethereum development
- TanStack Query for data management
- Shadcn UI components

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.