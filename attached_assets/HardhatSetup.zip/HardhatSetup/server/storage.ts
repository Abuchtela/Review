import { 
  users, type User, type InsertUser,
  contracts, type Contract, type InsertContract,
  securityTools, type SecurityTool, type InsertSecurityTool,
  testCases, type TestCase, type InsertTestCase,
  findings, type Finding, type InsertFinding
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Contract operations
  getContract(id: number): Promise<Contract | undefined>;
  getContracts(): Promise<Contract[]>;
  createContract(contract: InsertContract): Promise<Contract>;
  updateContract(id: number, contract: Partial<Contract>): Promise<Contract | undefined>;
  deleteContract(id: number): Promise<boolean>;

  // Security tool operations
  getSecurityTool(id: number): Promise<SecurityTool | undefined>;
  getSecurityTools(): Promise<SecurityTool[]>;
  createSecurityTool(tool: InsertSecurityTool): Promise<SecurityTool>;
  updateSecurityTool(id: number, tool: Partial<SecurityTool>): Promise<SecurityTool | undefined>;

  // Test case operations
  getTestCase(id: number): Promise<TestCase | undefined>;
  getTestCasesByContract(contractId: number): Promise<TestCase[]>;
  getAllTestCases(): Promise<TestCase[]>;
  createTestCase(testCase: InsertTestCase): Promise<TestCase>;
  updateTestCase(id: number, testCase: Partial<TestCase>): Promise<TestCase | undefined>;
  deleteTestCase(id: number): Promise<boolean>;

  // Finding operations
  getFinding(id: number): Promise<Finding | undefined>;
  getFindingsByContract(contractId: number): Promise<Finding[]>;
  getAllFindings(): Promise<Finding[]>;
  createFinding(finding: InsertFinding): Promise<Finding>;
  deleteFinding(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contracts: Map<number, Contract>;
  private securityTools: Map<number, SecurityTool>;
  private testCases: Map<number, TestCase>;
  private findings: Map<number, Finding>;
  
  // Counters for IDs
  private userIdCounter: number;
  private contractIdCounter: number;
  private toolIdCounter: number;
  private testCaseIdCounter: number;
  private findingIdCounter: number;

  constructor() {
    this.users = new Map();
    this.contracts = new Map();
    this.securityTools = new Map();
    this.testCases = new Map();
    this.findings = new Map();
    
    this.userIdCounter = 1;
    this.contractIdCounter = 1;
    this.toolIdCounter = 1;
    this.testCaseIdCounter = 1;
    this.findingIdCounter = 1;

    // Initialize with some default security tools
    this.initializeDefaultSecurityTools();
  }

  private initializeDefaultSecurityTools() {
    const defaultTools = [
      {
        id: this.toolIdCounter++,
        name: "Slither",
        version: "0.9.3",
        installed: false,
        configOptions: {
          detectors: ["reentrancy", "uninitialized-state", "uninitialized-storage", "arbitrary-send", "controlled-delegatecall"]
        }
      },
      {
        id: this.toolIdCounter++,
        name: "Mythril",
        version: "0.23.15",
        installed: false,
        configOptions: {
          analysis_mode: "standard",
          solc_version: "0.8.17"
        }
      },
      {
        id: this.toolIdCounter++,
        name: "Echidna",
        version: "2.0.5",
        installed: false,
        configOptions: {
          testLimit: 50000,
          seqLen: 100
        }
      }
    ];

    for (const tool of defaultTools) {
      this.securityTools.set(tool.id, tool);
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Contract operations
  async getContract(id: number): Promise<Contract | undefined> {
    return this.contracts.get(id);
  }

  async getContracts(): Promise<Contract[]> {
    return Array.from(this.contracts.values());
  }

  async createContract(contract: InsertContract): Promise<Contract> {
    const id = this.contractIdCounter++;
    const newContract: Contract = { 
      ...contract, 
      id, 
      dateAdded: new Date(),
      verified: contract.verified ?? null,
      securityScore: contract.securityScore ?? null
    };
    this.contracts.set(id, newContract);
    return newContract;
  }

  async updateContract(id: number, contractUpdate: Partial<Contract>): Promise<Contract | undefined> {
    const contract = this.contracts.get(id);
    if (!contract) return undefined;
    
    const updatedContract = { ...contract, ...contractUpdate };
    this.contracts.set(id, updatedContract);
    return updatedContract;
  }

  async deleteContract(id: number): Promise<boolean> {
    return this.contracts.delete(id);
  }

  // Security tool operations
  async getSecurityTool(id: number): Promise<SecurityTool | undefined> {
    return this.securityTools.get(id);
  }

  async getSecurityTools(): Promise<SecurityTool[]> {
    return Array.from(this.securityTools.values());
  }

  async createSecurityTool(tool: InsertSecurityTool): Promise<SecurityTool> {
    const id = this.toolIdCounter++;
    const newTool: SecurityTool = { 
      ...tool, 
      id,
      version: tool.version ?? null,
      installed: tool.installed ?? null,
      configOptions: tool.configOptions ?? null
    };
    this.securityTools.set(id, newTool);
    return newTool;
  }

  async updateSecurityTool(id: number, toolUpdate: Partial<SecurityTool>): Promise<SecurityTool | undefined> {
    const tool = this.securityTools.get(id);
    if (!tool) return undefined;
    
    const updatedTool = { ...tool, ...toolUpdate };
    this.securityTools.set(id, updatedTool);
    return updatedTool;
  }

  // Test case operations
  async getTestCase(id: number): Promise<TestCase | undefined> {
    return this.testCases.get(id);
  }

  async getTestCasesByContract(contractId: number): Promise<TestCase[]> {
    return Array.from(this.testCases.values()).filter(
      (testCase) => testCase.contractId === contractId
    );
  }

  async getAllTestCases(): Promise<TestCase[]> {
    return Array.from(this.testCases.values());
  }

  async createTestCase(testCase: InsertTestCase): Promise<TestCase> {
    const id = this.testCaseIdCounter++;
    const newTestCase: TestCase = { 
      ...testCase, 
      id, 
      description: testCase.description ?? null,
      lastRun: null,
      passed: null
    };
    this.testCases.set(id, newTestCase);
    return newTestCase;
  }

  async updateTestCase(id: number, testCaseUpdate: Partial<TestCase>): Promise<TestCase | undefined> {
    const testCase = this.testCases.get(id);
    if (!testCase) return undefined;
    
    const updatedTestCase = { ...testCase, ...testCaseUpdate };
    this.testCases.set(id, updatedTestCase);
    return updatedTestCase;
  }

  async deleteTestCase(id: number): Promise<boolean> {
    return this.testCases.delete(id);
  }

  // Finding operations
  async getFinding(id: number): Promise<Finding | undefined> {
    return this.findings.get(id);
  }

  async getFindingsByContract(contractId: number): Promise<Finding[]> {
    return Array.from(this.findings.values()).filter(
      (finding) => finding.contractId === contractId
    );
  }

  async getAllFindings(): Promise<Finding[]> {
    return Array.from(this.findings.values());
  }

  async createFinding(finding: InsertFinding): Promise<Finding> {
    const id = this.findingIdCounter++;
    const newFinding: Finding = { 
      ...finding, 
      id, 
      dateFound: new Date(),
      code: finding.code ?? null,
      testCaseId: finding.testCaseId ?? null,
      toolId: finding.toolId ?? null,
      recommendation: finding.recommendation ?? null
    };
    this.findings.set(id, newFinding);
    return newFinding;
  }

  async deleteFinding(id: number): Promise<boolean> {
    return this.findings.delete(id);
  }
}

// Create a singleton instance
export const storage = new MemStorage();
