import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContractSchema, insertSecurityToolSchema, insertTestCaseSchema, insertFindingSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { exec } from "child_process";
import { promisify } from "util";
import path from "path";
import fs from "fs/promises";

const execPromise = promisify(exec);

export async function registerRoutes(app: Express): Promise<Server> {
  // Contracts API
  app.get("/api/contracts", async (req, res) => {
    const contracts = await storage.getContracts();
    res.json(contracts);
  });

  app.get("/api/contracts/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid contract ID" });
    }

    const contract = await storage.getContract(id);
    if (!contract) {
      return res.status(404).json({ message: "Contract not found" });
    }

    res.json(contract);
  });

  app.post("/api/contracts", async (req, res) => {
    try {
      const contractData = insertContractSchema.parse(req.body);
      const contract = await storage.createContract(contractData);
      res.status(201).json(contract);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to create contract" });
    }
  });

  app.patch("/api/contracts/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid contract ID" });
    }

    try {
      const updatedContract = await storage.updateContract(id, req.body);
      if (!updatedContract) {
        return res.status(404).json({ message: "Contract not found" });
      }
      res.json(updatedContract);
    } catch (error) {
      res.status(500).json({ message: "Failed to update contract" });
    }
  });

  app.delete("/api/contracts/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid contract ID" });
    }

    const success = await storage.deleteContract(id);
    if (!success) {
      return res.status(404).json({ message: "Contract not found" });
    }
    
    res.status(204).end();
  });

  // Security Tools API
  app.get("/api/security-tools", async (req, res) => {
    const tools = await storage.getSecurityTools();
    res.json(tools);
  });

  app.get("/api/security-tools/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid tool ID" });
    }

    const tool = await storage.getSecurityTool(id);
    if (!tool) {
      return res.status(404).json({ message: "Security tool not found" });
    }

    res.json(tool);
  });

  app.post("/api/security-tools", async (req, res) => {
    try {
      const toolData = insertSecurityToolSchema.parse(req.body);
      const tool = await storage.createSecurityTool(toolData);
      res.status(201).json(tool);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to create security tool" });
    }
  });

  app.patch("/api/security-tools/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid tool ID" });
    }

    try {
      const updatedTool = await storage.updateSecurityTool(id, req.body);
      if (!updatedTool) {
        return res.status(404).json({ message: "Security tool not found" });
      }
      res.json(updatedTool);
    } catch (error) {
      res.status(500).json({ message: "Failed to update security tool" });
    }
  });

  // Test Cases API
  app.get("/api/test-cases", async (req, res) => {
    const contractId = req.query.contractId ? parseInt(req.query.contractId as string) : undefined;
    
    if (contractId) {
      if (isNaN(contractId)) {
        return res.status(400).json({ message: "Invalid contract ID" });
      }
      const testCases = await storage.getTestCasesByContract(contractId);
      return res.json(testCases);
    }
    
    const testCases = await storage.getAllTestCases();
    res.json(testCases);
  });

  app.get("/api/test-cases/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid test case ID" });
    }

    const testCase = await storage.getTestCase(id);
    if (!testCase) {
      return res.status(404).json({ message: "Test case not found" });
    }

    res.json(testCase);
  });

  app.post("/api/test-cases", async (req, res) => {
    try {
      const testCaseData = insertTestCaseSchema.parse(req.body);
      const testCase = await storage.createTestCase(testCaseData);
      res.status(201).json(testCase);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to create test case" });
    }
  });

  app.patch("/api/test-cases/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid test case ID" });
    }

    try {
      const updatedTestCase = await storage.updateTestCase(id, req.body);
      if (!updatedTestCase) {
        return res.status(404).json({ message: "Test case not found" });
      }
      res.json(updatedTestCase);
    } catch (error) {
      res.status(500).json({ message: "Failed to update test case" });
    }
  });

  app.delete("/api/test-cases/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid test case ID" });
    }

    const success = await storage.deleteTestCase(id);
    if (!success) {
      return res.status(404).json({ message: "Test case not found" });
    }
    
    res.status(204).end();
  });

  // Findings API
  app.get("/api/findings", async (req, res) => {
    const contractId = req.query.contractId ? parseInt(req.query.contractId as string) : undefined;
    
    if (contractId) {
      if (isNaN(contractId)) {
        return res.status(400).json({ message: "Invalid contract ID" });
      }
      const findings = await storage.getFindingsByContract(contractId);
      return res.json(findings);
    }
    
    const findings = await storage.getAllFindings();
    res.json(findings);
  });

  app.post("/api/findings", async (req, res) => {
    try {
      const findingData = insertFindingSchema.parse(req.body);
      const finding = await storage.createFinding(findingData);
      res.status(201).json(finding);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to create finding" });
    }
  });

  app.delete("/api/findings/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid finding ID" });
    }

    const success = await storage.deleteFinding(id);
    if (!success) {
      return res.status(404).json({ message: "Finding not found" });
    }
    
    res.status(204).end();
  });

  // Hardhat API - Installation simulation
  app.post("/api/hardhat/setup", async (req, res) => {
    try {
      // Simulate hardhat installation
      await new Promise(resolve => setTimeout(resolve, 1500));
      res.json({ success: true, message: "Hardhat environment setup successfully" });
    } catch (error) {
      res.status(500).json({ success: false, message: "Failed to setup Hardhat environment" });
    }
  });

  // Security tools installation simulation
  app.post("/api/security-tools/:id/install", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid tool ID" });
    }

    try {
      const tool = await storage.getSecurityTool(id);
      if (!tool) {
        return res.status(404).json({ message: "Security tool not found" });
      }

      // Simulate installation process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mark tool as installed
      const updatedTool = await storage.updateSecurityTool(id, { installed: true });
      res.json({ success: true, tool: updatedTool });
    } catch (error) {
      res.status(500).json({ success: false, message: "Failed to install security tool" });
    }
  });
  
  // Run security tool analysis simulation
  app.post("/api/security-tools/:id/analyze", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid tool ID" });
    }

    try {
      const tool = await storage.getSecurityTool(id);
      if (!tool) {
        return res.status(404).json({ message: "Security tool not found" });
      }
      
      if (!tool.installed) {
        return res.status(400).json({ 
          success: false, 
          message: "Tool must be installed before running analysis" 
        });
      }

      // Get contracts to analyze
      const contracts = await storage.getContracts();
      if (contracts.length === 0) {
        return res.status(400).json({ 
          success: false, 
          message: "No contracts available for analysis" 
        });
      }

      // Simulate analysis process
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Generate sample findings based on the tool type
      const findings = [];
      
      for (const contract of contracts) {
        // Generate 0-3 findings per contract with varying severity
        const numFindings = Math.floor(Math.random() * 4);
        
        for (let i = 0; i < numFindings; i++) {
          // Random severity
          const severities = ["critical", "high", "medium", "low"];
          const severity = severities[Math.floor(Math.random() * severities.length)];
          
          // Generate Optimism-specific vulnerability titles based on severity
          let title = "";
          let description = "";
          let recommendation = "";
          
          // Optimism-specific vulnerability categories
          if (severity === "critical") {
            // Select from critical severity vulnerabilities
            const criticalVulnerabilities = [
              {
                title: "Loss of user funds by direct theft",
                description: "Vulnerability allows an attacker to directly steal user funds from the contract.",
                recommendation: "Implement proper access controls, validation checks, and reentrancy guards to prevent unauthorized fund transfers."
              },
              {
                title: "Permanent freezing of funds",
                description: "Vulnerability results in user funds being permanently locked in the contract with no recovery method.",
                recommendation: "Add recovery mechanisms and ensure critical functions have proper error handling to prevent permanent lockup states."
              },
              {
                title: "Protocol insolvency",
                description: "Vulnerability could lead to protocol-wide insolvency, affecting all users of the system.",
                recommendation: "Implement economic safety checks, liquidity thresholds, and proper accounting mechanisms to maintain protocol solvency."
              }
            ];
            
            const selected = criticalVulnerabilities[Math.floor(Math.random() * criticalVulnerabilities.length)];
            title = selected.title;
            description = selected.description;
            recommendation = selected.recommendation;
          } 
          else if (severity === "high") {
            // Select from high severity vulnerabilities
            const highVulnerabilities = [
              {
                title: "Temporary freezing of funds",
                description: "Vulnerability results in user funds being temporarily locked, recoverable via an upgrade.",
                recommendation: "Implement circuit breakers and recovery processes that can be triggered by governance to unfreeze assets."
              },
              {
                title: "Incorrectly resolved dispute game",
                description: "Vulnerability allows a dispute game to be incorrectly resolved, mitigated by a delay mechanism.",
                recommendation: "Add additional verification checks and timelock mechanisms before finalizing dispute resolution."
              },
              {
                title: "Incorrectly proven withdrawal",
                description: "Vulnerability allows incorrect withdrawal proof to be accepted, mitigated by a delay.",
                recommendation: "Strengthen withdrawal proof verification and add timelock delays for large withdrawals."
              },
              {
                title: "Incorrectly initiated bond withdrawal",
                description: "Vulnerability allows unauthorized bond withdrawal initiation, mitigated by a delay.",
                recommendation: "Implement multi-signature requirements or timelock delays for bond withdrawals."
              }
            ];
            
            const selected = highVulnerabilities[Math.floor(Math.random() * highVulnerabilities.length)];
            title = selected.title;
            description = selected.description;
            recommendation = selected.recommendation;
          } 
          else if (severity === "medium") {
            // Medium severity vulnerabilities
            title = "Incorrectly resolved dispute game (with specific conditions)";
            description = "Vulnerability allows dispute games to be incorrectly resolved when calling FaultDisputeGame.step() against a claim at MAX_GAME_DEPTH or calling attack/defend at MAX_GAME_DEPTH-2.";
            recommendation = "Add safety checks specifically for operations near MAX_GAME_DEPTH and implement proper validation for step, attack, and defend functions.";
          } 
          else {
            // Low severity for other cases
            const lowVulnerabilities = [
              {
                title: "Gas optimization issue",
                description: "Contract uses excessive gas for operations that could be optimized.",
                recommendation: "Refactor code to reduce gas consumption in critical functions."
              },
              {
                title: "Timestamp dependence",
                description: "Contract relies on block.timestamp for non-critical operations.",
                recommendation: "Consider more reliable time measurement mechanisms for time-sensitive operations."
              },
              {
                title: "Minor logic inconsistency",
                description: "Contract contains logic that may behave unexpectedly in edge cases.",
                recommendation: "Add explicit checks for edge cases and clarify logic flow."
              }
            ];
            
            const selected = lowVulnerabilities[Math.floor(Math.random() * lowVulnerabilities.length)];
            title = selected.title;
            description = selected.description;
            recommendation = selected.recommendation;
          }
          
          // Add tool-specific context if needed
          if (tool.name === "Slither") {
            description = `${description} Detected by static analysis.`;
          } else if (tool.name === "Mythril") {
            description = `${description} Detected by symbolic execution.`;
          } else if (tool.name === "Echidna") {
            description = `${description} Detected by property-based fuzzing.`;
          }
          
          // Create finding
          const finding = await storage.createFinding({
            contractId: contract.id,
            toolId: tool.id,
            testCaseId: null,
            severity: severity as any,
            title,
            description,
            recommendation,
            code: contract.source.substring(0, 500) // Just use a portion of the code for demo
          });
          
          findings.push(finding);
        }
      }

      res.json({ 
        success: true,
        findings,
        message: `Analysis completed. Found ${findings.length} issues.`
      });
    } catch (error) {
      console.error('Error running analysis:', error);
      res.status(500).json({ success: false, message: "Failed to run analysis" });
    }
  });

  // Run tests simulation
  app.post("/api/test-cases/:id/run", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid test case ID" });
    }

    try {
      const testCase = await storage.getTestCase(id);
      if (!testCase) {
        return res.status(404).json({ message: "Test case not found" });
      }

      // Simulate test run
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Update test case with results
      const passed = Math.random() > 0.3; // 70% chance of success for demo
      const updatedTestCase = await storage.updateTestCase(id, { 
        lastRun: new Date(),
        passed
      });

      // If test failed, create a finding with Optimism-specific vulnerability categories
      if (!passed) {
        // Randomly choose severity with higher probability for medium/high
        const severityRoll = Math.random();
        let severity;
        let title;
        let description;
        let recommendation;
        
        if (severityRoll < 0.1) { // 10% chance for critical
          severity = "critical";
          const criticalOptions = [
            {
              title: "Loss of user funds by direct theft",
              description: `Test '${testCase.name}' detected a vulnerability that could allow direct theft of user funds.`,
              recommendation: "Implement proper access controls and reentrancy guards to prevent unauthorized fund transfers."
            },
            {
              title: "Permanent freezing of funds",
              description: `Test '${testCase.name}' detected a vulnerability that could permanently lock user funds.`,
              recommendation: "Add recovery mechanisms and ensure critical functions have proper error handling."
            }
          ];
          const selected = criticalOptions[Math.floor(Math.random() * criticalOptions.length)];
          title = selected.title;
          description = selected.description;
          recommendation = selected.recommendation;
        } 
        else if (severityRoll < 0.3) { // 20% chance for high
          severity = "high";
          const highOptions = [
            {
              title: "Temporary freezing of funds",
              description: `Test '${testCase.name}' detected a vulnerability that could temporarily lock user funds.`,
              recommendation: "Implement circuit breakers and recovery mechanisms that can be triggered by governance."
            },
            {
              title: "Incorrectly resolved dispute game",
              description: `Test '${testCase.name}' detected a vulnerability that allows dispute games to be incorrectly resolved.`,
              recommendation: "Add additional verification checks and timelock mechanisms before finalizing dispute resolution."
            }
          ];
          const selected = highOptions[Math.floor(Math.random() * highOptions.length)];
          title = selected.title;
          description = selected.description;
          recommendation = selected.recommendation;
        } 
        else if (severityRoll < 0.7) { // 40% chance for medium
          severity = "medium";
          title = "Incorrectly resolved dispute game (with specific conditions)";
          description = `Test '${testCase.name}' revealed a vulnerability in the dispute game resolution when specific conditions are met.`;
          recommendation = "Add safety checks for operations near MAX_GAME_DEPTH and implement proper validation for game functions.";
        } 
        else { // 30% chance for low
          severity = "low";
          title = "Gas optimization issue";
          description = `Test '${testCase.name}' identified inefficient gas usage patterns.`;
          recommendation = "Refactor code to reduce gas consumption in frequently called functions.";
        }

        const finding = await storage.createFinding({
          contractId: testCase.contractId,
          testCaseId: id,
          toolId: null,
          severity: severity as any,
          title,
          description,
          recommendation,
          code: testCase.code
        });
      }

      res.json({ 
        success: true, 
        testCase: updatedTestCase,
        result: {
          passed,
          output: passed 
            ? "Test completed successfully. No vulnerabilities detected."
            : "Test failed. Potential vulnerability detected."
        }
      });
    } catch (error) {
      res.status(500).json({ success: false, message: "Failed to run test case" });
    }
  });

  // Generate report
  app.post("/api/reports/generate", async (req, res) => {
    try {
      const findings = await storage.getAllFindings();
      const contracts = await storage.getContracts();

      const criticalCount = findings.filter(f => f.severity === "critical").length;
      const highCount = findings.filter(f => f.severity === "high").length;
      const mediumCount = findings.filter(f => f.severity === "medium").length;
      const lowCount = findings.filter(f => f.severity === "low").length;

      res.json({
        generated: new Date(),
        summary: {
          contractsAnalyzed: contracts.length,
          findings: findings.length,
          severityCounts: {
            critical: criticalCount,
            high: highCount,
            medium: mediumCount,
            low: lowCount
          }
        },
        findings: findings
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate report" });
    }
  });

  // List available Optimism contracts from contracts directory
  app.get("/api/optimism-contracts", async (req, res) => {
    try {
      const contractsPath = path.resolve("contracts");
      const files = await fs.readdir(contractsPath);
      const contractFiles = files.filter(file => file.endsWith('.sol'));
      
      const contractsInfo = await Promise.all(contractFiles.map(async (file) => {
        const filePath = path.join(contractsPath, file);
        const content = await fs.readFile(filePath, 'utf8');
        
        // Extract contract name from file name (removing the .sol extension)
        const name = file.replace('.sol', '');
        
        // Extract first comment description if available
        let description = "";
        const descriptionMatch = content.match(/\/\*\*([\s\S]*?)\*\//);
        if (descriptionMatch && descriptionMatch[1]) {
          description = descriptionMatch[1]
            .replace(/\s*\*\s*/g, ' ')
            .trim();
        } else {
          const singleLineComment = content.match(/\/\/\s*(.*)/);
          if (singleLineComment && singleLineComment[1]) {
            description = singleLineComment[1].trim();
          }
        }
        
        return {
          name,
          fileName: file,
          description,
          path: filePath
        };
      }));
      
      res.json(contractsInfo);
    } catch (error) {
      console.error('Error listing Optimism contracts:', error);
      res.status(500).json({ message: "Failed to list Optimism contracts" });
    }
  });

  // Import a specific Optimism contract into the system
  app.post("/api/optimism-contracts/import", async (req, res) => {
    try {
      const { fileName } = req.body;
      
      if (!fileName) {
        return res.status(400).json({ message: "Contract file name is required" });
      }
      
      const contractsPath = path.resolve("contracts");
      const filePath = path.join(contractsPath, fileName);
      
      // Check if the file exists
      try {
        await fs.access(filePath);
      } catch (error) {
        return res.status(404).json({ message: "Contract file not found" });
      }
      
      // Read the contract source code
      const source = await fs.readFile(filePath, 'utf8');
      
      // Extract contract name from file name (removing the .sol extension)
      const name = fileName.replace('.sol', '');
      
      // Create a new contract entry
      const newContract = {
        name,
        address: '0x' + '0'.repeat(40), // Placeholder address for imported contracts
        source,
        network: 'optimism-local',
        verified: true
      };
      
      const contract = await storage.createContract(newContract);
      res.status(201).json(contract);
    } catch (error) {
      console.error('Error importing Optimism contract:', error);
      res.status(500).json({ message: "Failed to import Optimism contract" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
